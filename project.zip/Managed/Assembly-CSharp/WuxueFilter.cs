public enum WuxueFilter
{
	ALL,
	QUAN,
	JIAN,
	DAO,
	QIMEN,
	NEIGONG,
	XIANSHU
}
