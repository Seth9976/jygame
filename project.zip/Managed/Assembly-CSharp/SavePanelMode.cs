public enum SavePanelMode
{
	SAVE,
	LOAD
}
