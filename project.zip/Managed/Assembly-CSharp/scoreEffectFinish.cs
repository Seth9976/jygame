using UnityEngine;

public class scoreEffectFinish : StateMachineBehaviour
{
}
