namespace JyGame;

public enum SkillStatus
{
	Ok,
	NoBalls,
	NoCd,
	NoMp,
	Seal,
	Error
}
