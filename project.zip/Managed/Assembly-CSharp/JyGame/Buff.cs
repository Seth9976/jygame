using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;

namespace JyGame;

public class Buff
{
	[CompilerGenerated]
	private sealed class _200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E : IEnumerable<Buff>, IEnumerator<Buff>, IEnumerator, IDisposable, IEnumerable
	{
		internal string content;

		internal string[] _200B_202D_202A_206C_206C_200B_202C_202B_200E_206B_206F_206C_200F_200E_202A_200C_202D_200F_200C_200F_200C_206F_206B_200E_206D_200E_206B_206D_200E_200B_202E_206F_206E_202E_206B_200C_206E_200F_200C_200E_202E;

		internal string[] _200C_206E_200E_200F_202A_202B_206C_200C_206C_206E_202D_206B_200B_202C_206F_206E_206F_200B_200F_200D_200C_200D_200F_200E_200E_202D_206E_202C_206E_202A_200E_206C_206F_202D_206E_206C_206D_206C_206B_206D_202E;

		internal int _200E_200D_200D_200F_202C_206C_206B_202C_206B_202C_206F_200C_206D_206F_200D_202B_206F_200E_206A_200C_206C_202A_202E_200D_206C_202D_206F_206C_202A_206C_202E_206A_206A_206F_200F_200B_206C_206B_200F_206F_202E;

		internal string _200B_206B_206A_206C_206E_206C_200F_202E_206C_200D_206E_200D_200E_206A_200F_200B_200B_200E_206C_202E_202C_200C_206D_206F_202D_200D_206E_202C_200C_206B_202A_200F_206C_206F_202C_202D_200D_200B_200C_206F_202E;

		internal string[] _200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E;

		internal string _206F_206C_200F_206E_200C_200E_206A_206D_200D_200C_202D_206D_202D_200D_202C_202C_206B_200C_206E_206F_200B_202D_200C_200D_200F_202C_206C_200E_202C_206C_206F_200C_200B_202B_202E_202B_200F_202B_206D_202A_202E;

		internal int _206A_200D_202B_206D_202C_206F_206D_206F_202C_202D_200C_206E_200E_200E_200E_200D_206C_206D_206B_202B_200C_206A_206C_200C_200D_202B_206E_202D_202B_200F_202E_200F_206F_200F_202B_206D_202A_200D_200B_202A_202E;

		internal int _200F_202D_202A_206B_206D_200F_206F_202D_206F_200C_206B_206C_202E_206D_202D_206D_206B_202E_200D_200B_202D_206E_206B_200E_206F_206B_202C_202B_200B_202B_206F_206B_200B_200C_200B_200E_206C_200C_202B_206D_202E;

		internal int _200C_206F_202E_202D_202C_206B_200D_202C_206F_200E_206C_200F_206E_206D_206E_200F_200F_200B_200C_202B_202C_206E_202E_200C_202A_206C_206C_206F_206C_200C_200E_200F_206A_206A_206F_200F_206F_206B_206E_202C_202E;

		internal int _0024PC;

		internal Buff _0024current;

		internal string _206F_200D_206C_206E_206B_200D_200E_200B_200F_206F_206A_200E_200F_206C_206A_206A_202C_202A_206E_202A_202A_200C_200C_206B_200D_200D_202C_206F_202B_206C_202C_206D_200F_200D_200C_206C_206A_202E_202D_206E_202E;

		Buff IEnumerator<Buff>.Current
		{
			[DebuggerHidden]
			get
			{
				return _0024current;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _0024current;
			}
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			return System_002ECollections_002EGeneric_002EIEnumerable_003CJyGame_002EBuff_003E_002EGetEnumerator();
		}

		[DebuggerHidden]
		IEnumerator<Buff> IEnumerable<Buff>.GetEnumerator()
		{
			if (_200B_200C_202A_202B_206D_202C_200E_200F_206F_202C_200C_202C_206A_200B_206A_200E_206A_202E_202B_200F_202B_200B_200F_200F_200D_202A_206F_202E_206A_206D_200D_206C_200D_206C_200B_202C_206F_202A_202D_202E(ref _0024PC, 0, -2) == -2)
			{
				goto IL_0012;
			}
			goto IL_0049;
			IL_0012:
			int num = 261915472;
			goto IL_0017;
			IL_0017:
			uint num2;
			_200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E result = default(_200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E);
			switch ((num2 = (uint)(num ^ 0x4C6712D9)) % 4)
			{
			case 0u:
				break;
			case 1u:
				return this;
			case 2u:
				goto IL_0049;
			default:
				return result;
			}
			goto IL_0012;
			IL_0049:
			result = new _200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E
			{
				content = _206F_200D_206C_206E_206B_200D_200E_200B_200F_206F_206A_200E_200F_206C_206A_206A_202C_202A_206E_202A_202A_200C_200C_206B_200D_200D_202C_206F_202B_206C_202C_206D_200F_200D_200C_206C_206A_202E_202D_206E_202E
			};
			num = 1303518326;
			goto IL_0017;
		}

		public bool MoveNext()
		{
			uint num = (uint)_0024PC;
			bool result = default(bool);
			while (true)
			{
				int num2 = -872212498;
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)(num2 ^ -2036725521)) % 26)
					{
					case 16u:
						break;
					case 24u:
					{
						int num6;
						if (_206D_206E_202E_206E_200D_206A_200B_200D_202A_206E_206C_200C_202E_206C_200D_206E_200C_200D_200E_202C_202A_200B_200B_200F_200F_202E_202A_200E_200F_200E_200E_206E_202E_200C_200C_202B_200C_200F_200D_200C_202E(content))
						{
							num2 = -1074967681;
							num6 = num2;
						}
						else
						{
							num2 = -1987292898;
							num6 = num2;
						}
						continue;
					}
					case 0u:
						_200B_206B_206A_206C_206E_206C_200F_202E_206C_200D_206E_200D_200E_206A_200F_200B_200B_200E_206C_202E_202C_200C_206D_206F_202D_200D_206E_202C_200C_206B_202A_200F_206C_206F_202C_202D_200D_200B_200C_206F_202E = _200C_206E_200E_200F_202A_202B_206C_200C_206C_206E_202D_206B_200B_202C_206F_206E_206F_200B_200F_200D_200C_200D_200F_200E_200E_202D_206E_202C_206E_202A_200E_206C_206F_202D_206E_206C_206D_206C_206B_206D_202E[_200E_200D_200D_200F_202C_206C_206B_202C_206B_202C_206F_200C_206D_206F_200D_202B_206F_200E_206A_200C_206C_202A_202E_200D_206C_202D_206F_206C_202A_206C_202E_206A_206A_206F_200F_200B_206C_206B_200F_206F_202E];
						num2 = -1550504670;
						continue;
					case 5u:
						_200B_202D_202A_206C_206C_200B_202C_202B_200E_206B_206F_206C_200F_200E_202A_200C_202D_200F_200C_200F_200C_206F_206B_200E_206D_200E_206B_206D_200E_200B_202E_206F_206E_202E_206B_200C_206E_200F_200C_200E_202E = _200B_206C_206B_200C_200D_200B_200F_200C_200E_206A_206B_206D_206E_200C_202A_202A_200E_202C_206E_202A_200C_206C_200B_206D_206D_200C_206A_206C_206F_202E_206E_200D_202D_202C_200B_202B_206A_200B_200C_202B_202E(content, new char[1] { '#' });
						num2 = -1973591743;
						continue;
					case 2u:
						num2 = (int)(num3 * 1757462516) ^ -2046092710;
						continue;
					case 7u:
						_0024PC = -1;
						switch (num)
						{
						case 0u:
							break;
						default:
							goto IL_0114;
						case 1u:
							goto IL_0260;
						}
						goto case 24u;
					case 21u:
					{
						int num7;
						int num8;
						if (_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E.Length <= 2)
						{
							num7 = -1620585814;
							num8 = num7;
						}
						else
						{
							num7 = -693185405;
							num8 = num7;
						}
						num2 = num7 ^ ((int)num3 * -193763189);
						continue;
					}
					case 25u:
						return false;
					case 8u:
						num2 = (int)(num3 * 595201312) ^ -91118948;
						continue;
					case 15u:
						num2 = ((int)num3 * -223486168) ^ 0x65F2EF30;
						continue;
					case 6u:
						_206A_200D_202B_206D_202C_206F_206D_206F_202C_202D_200C_206E_200E_200E_200E_200D_206C_206D_206B_202B_200C_206A_206C_200C_200D_202B_206E_202D_202B_200F_202E_200F_206F_200F_202B_206D_202A_200D_200B_202A_202E = 1;
						num2 = (int)(num3 * 1198294967) ^ -1687819015;
						continue;
					case 22u:
						_200F_202D_202A_206B_206D_200F_206F_202D_206F_200C_206B_206C_202E_206D_202D_206D_206B_202E_200D_200B_202D_206E_206B_200E_206F_206B_202C_202B_200B_202B_206F_206B_200B_200C_200B_200E_206C_200C_202B_206D_202E = 3;
						num2 = (int)((num3 * 58326299) ^ 0x32DA074D);
						continue;
					case 10u:
						_0024current = new Buff
						{
							Name = _206F_206C_200F_206E_200C_200E_206A_206D_200D_200C_202D_206D_202D_200D_202C_202C_206B_200C_206E_206F_200B_202D_200C_200D_200F_202C_206C_200E_202C_206C_206F_200C_200B_202B_202E_202B_200F_202B_206D_202A_202E,
							Level = _206A_200D_202B_206D_202C_206F_206D_206F_202C_202D_200C_206E_200E_200E_200E_200D_206C_206D_206B_202B_200C_206A_206C_200C_200D_202B_206E_202D_202B_200F_202E_200F_206F_200F_202B_206D_202A_200D_200B_202A_202E,
							Round = _200F_202D_202A_206B_206D_200F_206F_202D_206F_200C_206B_206C_202E_206D_202D_206D_206B_202E_200D_200B_202D_206E_206B_200E_206F_206B_202C_202B_200B_202B_206F_206B_200B_200C_200B_200E_206C_200C_202B_206D_202E,
							Property = _200C_206F_202E_202D_202C_206B_200D_202C_206F_200E_206C_200F_206E_206D_206E_200F_200F_200B_200C_202B_202C_206E_202E_200C_202A_206C_206C_206F_206C_200C_200E_200F_206A_206A_206F_200F_206F_206B_206E_202C_202E
						};
						num2 = -1999481992;
						continue;
					case 9u:
						_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E = _200B_206C_206B_200C_200D_200B_200F_200C_200E_206A_206B_206D_206E_200C_202A_202A_200E_202C_206E_202A_200C_206C_200B_206D_206D_200C_206A_206C_206F_202E_206E_200D_202D_202C_200B_202B_206A_200B_200C_202B_202E(_200B_206B_206A_206C_206E_206C_200F_202E_206C_200D_206E_200D_200E_206A_200F_200B_200B_200E_206C_202E_202C_200C_206D_206F_202D_200D_206E_202C_200C_206B_202A_200F_206C_206F_202C_202D_200D_200B_200C_206F_202E, new char[1] { '.' });
						_206F_206C_200F_206E_200C_200E_206A_206D_200D_200C_202D_206D_202D_200D_202C_202C_206B_200C_206E_206F_200B_202D_200C_200D_200F_202C_206C_200E_202C_206C_206F_200C_200B_202B_202E_202B_200F_202B_206D_202A_202E = _200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E[0];
						num2 = (int)(num3 * 1562365294) ^ -608717677;
						continue;
					case 18u:
					{
						_200C_206F_202E_202D_202C_206B_200D_202C_206F_200E_206C_200F_206E_206D_206E_200F_200F_200B_200C_202B_202C_206E_202E_200C_202A_206C_206C_206F_206C_200C_200E_200F_206A_206A_206F_200F_206F_206B_206E_202C_202E = -1;
						int num10;
						int num11;
						if (_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E.Length > 1)
						{
							num10 = -1209393270;
							num11 = num10;
						}
						else
						{
							num10 = -1297220147;
							num11 = num10;
						}
						num2 = num10 ^ (int)(num3 * 775974378);
						continue;
					}
					case 13u:
						goto IL_0260;
					case 23u:
					{
						int num9;
						if (_200E_200D_200D_200F_202C_206C_206B_202C_206B_202C_206F_200C_206D_206F_200D_202B_206F_200E_206A_200C_206C_202A_202E_200D_206C_202D_206F_206C_202A_206C_202E_206A_206A_206F_200F_200B_206C_206B_200F_206F_202E < _200C_206E_200E_200F_202A_202B_206C_200C_206C_206E_202D_206B_200B_202C_206F_206E_206F_200B_200F_200D_200C_200D_200F_200E_200E_202D_206E_202C_206E_202A_200E_206C_206F_202D_206E_206C_206D_206C_206B_206D_202E.Length)
						{
							num2 = -747385741;
							num9 = num2;
						}
						else
						{
							num2 = -1874406669;
							num9 = num2;
						}
						continue;
					}
					case 19u:
						return true;
					case 4u:
						num2 = ((int)num3 * -593038553) ^ 0x7A53A4F8;
						continue;
					case 20u:
						_0024PC = -1;
						num2 = (int)(num3 * 370076964) ^ -42087944;
						continue;
					case 3u:
						_200C_206F_202E_202D_202C_206B_200D_202C_206F_200E_206C_200F_206E_206D_206E_200F_200F_200B_200C_202B_202C_206E_202E_200C_202A_206C_206C_206F_206C_200C_200E_200F_206A_206A_206F_200F_206F_206B_206E_202C_202E = _206E_206C_206C_206E_200E_202A_200D_206C_206D_200C_200B_200B_202C_200D_202C_200C_206C_200B_206F_206F_206A_202A_202A_202E_202A_202D_202C_200C_206F_202A_200D_202A_206A_200D_202A_200D_206F_200E_206F_206A_202E(int.Parse(_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E[3]), 100);
						num2 = (int)((num3 * 1277181954) ^ 0x23BE93AF);
						continue;
					case 11u:
						_206A_200D_202B_206D_202C_206F_206D_206F_202C_202D_200C_206E_200E_200E_200E_200D_206C_206D_206B_202B_200C_206A_206C_200C_200D_202B_206E_202D_202B_200F_202E_200F_206F_200F_202B_206D_202A_200D_200B_202A_202E = int.Parse(_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E[1]);
						num2 = ((int)num3 * -1978935064) ^ 0x3254B19E;
						continue;
					case 17u:
						_0024PC = 1;
						num2 = ((int)num3 * -1893847105) ^ -1057356772;
						continue;
					case 12u:
						_200C_206E_200E_200F_202A_202B_206C_200C_206C_206E_202D_206B_200B_202C_206F_206E_206F_200B_200F_200D_200C_200D_200F_200E_200E_202D_206E_202C_206E_202A_200E_206C_206F_202D_206E_206C_206D_206C_206B_206D_202E = _200B_202D_202A_206C_206C_200B_202C_202B_200E_206B_206F_206C_200F_200E_202A_200C_202D_200F_200C_200F_200C_206F_206B_200E_206D_200E_206B_206D_200E_200B_202E_206F_206E_202E_206B_200C_206E_200F_200C_200E_202E;
						_200E_200D_200D_200F_202C_206C_206B_202C_206B_202C_206F_200C_206D_206F_200D_202B_206F_200E_206A_200C_206C_202A_202E_200D_206C_202D_206F_206C_202A_206C_202E_206A_206A_206F_200F_200B_206C_206B_200F_206F_202E = 0;
						num2 = (int)((num3 * 463539029) ^ 0x3A24CF99);
						continue;
					case 1u:
					{
						_200F_202D_202A_206B_206D_200F_206F_202D_206F_200C_206B_206C_202E_206D_202D_206D_206B_202E_200D_200B_202D_206E_206B_200E_206F_206B_202C_202B_200B_202B_206F_206B_200B_200C_200B_200E_206C_200C_202B_206D_202E = int.Parse(_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E[2]);
						int num4;
						int num5;
						if (_200B_202E_202B_206E_200F_206B_200C_200B_200D_200F_206F_200F_202E_206E_206E_206E_202C_206C_200F_200D_206D_206F_202D_200D_200E_200C_206E_206D_206C_206D_200D_202A_206C_206A_202C_202C_202A_202A_206C_202A_202E.Length > 3)
						{
							num4 = 322402986;
							num5 = num4;
						}
						else
						{
							num4 = 313999927;
							num5 = num4;
						}
						num2 = num4 ^ (int)(num3 * 1432055026);
						continue;
					}
					default:
						{
							return result;
						}
						IL_0114:
						num2 = ((int)num3 * -1733414791) ^ 0x298DE8D;
						continue;
						IL_0260:
						_200E_200D_200D_200F_202C_206C_206B_202C_206B_202C_206F_200C_206D_206F_200D_202B_206F_200E_206A_200C_206C_202A_202E_200D_206C_202D_206F_206C_202A_206C_202E_206A_206A_206F_200F_200B_206C_206B_200F_206F_202E++;
						num2 = -1460340326;
						continue;
					}
					break;
				}
			}
		}

		[DebuggerHidden]
		public void Dispose()
		{
			_0024PC = -1;
		}

		[DebuggerHidden]
		public void Reset()
		{
			throw _202C_206E_202E_200F_200B_206F_200B_206B_200D_202D_206B_206A_206D_206F_200B_206A_200F_206C_202E_200D_202A_202C_206A_200D_202B_200B_206B_202A_206E_206E_206F_202D_206A_206E_206B_200D_202B_200C_200E_206A_202E();
		}

		static int _200B_200C_202A_202B_206D_202C_200E_200F_206F_202C_200C_202C_206A_200B_206A_200E_206A_202E_202B_200F_202B_200B_200F_200F_200D_202A_206F_202E_206A_206D_200D_206C_200D_206C_200B_202C_206F_202A_202D_202E(ref int P_0, int P_1, int P_2)
		{
			return Interlocked.CompareExchange(ref P_0, P_1, P_2);
		}

		static bool _206D_206E_202E_206E_200D_206A_200B_200D_202A_206E_206C_200C_202E_206C_200D_206E_200C_200D_200E_202C_202A_200B_200B_200F_200F_202E_202A_200E_200F_200E_200E_206E_202E_200C_200C_202B_200C_200F_200D_200C_202E(string P_0)
		{
			return string.IsNullOrEmpty(P_0);
		}

		static string[] _200B_206C_206B_200C_200D_200B_200F_200C_200E_206A_206B_206D_206E_200C_202A_202A_200E_202C_206E_202A_200C_206C_200B_206D_206D_200C_206A_206C_206F_202E_206E_200D_202D_202C_200B_202B_206A_200B_200C_202B_202E(string P_0, char[] P_1)
		{
			return P_0.Split(P_1);
		}

		static int _206E_206C_206C_206E_200E_202A_200D_206C_206D_200C_200B_200B_202C_200D_202C_200C_206C_200B_206F_206F_206A_202A_202A_202E_202A_202D_202C_200C_206F_202A_200D_202A_206A_200D_202A_200D_206F_200E_206F_206A_202E(int P_0, int P_1)
		{
			return Math.Min(P_0, P_1);
		}

		static NotSupportedException _202C_206E_202E_200F_200B_206F_200B_206B_200D_202D_206B_206A_206D_206F_200B_206A_200F_206C_202E_200D_202A_202C_206A_200D_202B_200B_206B_202A_206E_206E_206F_202D_206A_206E_206B_200D_202B_200C_200E_206A_202E()
		{
			return new NotSupportedException();
		}
	}

	public static string[] BuffNames;

	public static string[] DebuffNames;

	public string Name;

	public int Level;

	public int Round = -1;

	public int Property = -1;

	public bool IsDebuff
	{
		get
		{
			string[] buffNames = BuffNames;
			int num = 0;
			while (true)
			{
				int num2 = 1118068544;
				while (true)
				{
					uint num3;
					switch ((num3 = (uint)(num2 ^ 0x44F3B1CF)) % 7)
					{
					case 0u:
						break;
					case 1u:
						num2 = ((int)num3 * -1338147504) ^ 0x725808A9;
						continue;
					case 4u:
					{
						int num5;
						if (num >= buffNames.Length)
						{
							num2 = 1003141325;
							num5 = num2;
						}
						else
						{
							num2 = 441265013;
							num5 = num2;
						}
						continue;
					}
					case 2u:
					{
						string text = buffNames[num];
						int num4;
						if (_206D_202D_206F_202A_206A_202C_206D_200B_200B_206D_202D_202C_206F_202E_202A_200F_206B_206A_206C_206F_202D_200C_202C_202E_200D_202E_200D_206D_202A_202D_206B_206F_206A_206E_202A_206A_202E_202D_202D_206E_202E(Name, text))
						{
							num2 = 1471807897;
							num4 = num2;
						}
						else
						{
							num2 = 813410272;
							num4 = num2;
						}
						continue;
					}
					case 5u:
						num++;
						num2 = 1632720665;
						continue;
					case 3u:
						return false;
					default:
						return true;
					}
					break;
				}
			}
		}
	}

	static Buff()
	{
	}

	public static string BuffsToString(List<Buff> buffs)
	{
		string text = default(string);
		if (buffs.Count > 0)
		{
			while (true)
			{
				int num = 330115069;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ 0x4AF90B28)) % 3)
					{
					case 0u:
						break;
					case 1u:
						goto IL_002e;
					default:
					{
						List<Buff>.Enumerator enumerator = buffs.GetEnumerator();
						try
						{
							while (true)
							{
								IL_00d3:
								int num3;
								int num4;
								if (enumerator.MoveNext())
								{
									num3 = 764643773;
									num4 = num3;
								}
								else
								{
									num3 = 1450785963;
									num4 = num3;
								}
								while (true)
								{
									switch ((num2 = (uint)(num3 ^ 0x4AF90B28)) % 4)
									{
									case 0u:
										num3 = 764643773;
										continue;
									default:
										goto end_IL_0054;
									case 1u:
									{
										Buff current = enumerator.Current;
										text = _206D_206E_206F_206C_206E_200E_200D_200B_202A_202E_202D_202E_206A_200F_200D_202D_206E_202B_206E_206E_200D_202C_200E_202B_206B_200F_206E_206E_206A_202E_206E_206A_200B_202A_206A_200B_200B_202C_202A_206F_202E(text, _200B_206A_202E_202D_206B_206E_202A_206E_200C_206D_206D_200F_202B_200D_202D_200D_206D_202B_202A_200E_206C_202E_206D_202E_206B_206C_202A_202D_200E_200B_202E_200C_202C_202A_206F_206E_206A_202D_206C_206A_202E(global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(15230987u), new object[4] { current.Name, current.Level, current.Round, current.Property }));
										num3 = 1430783666;
										continue;
									}
									case 2u:
										break;
									case 3u:
										goto end_IL_0054;
									}
									goto IL_00d3;
									continue;
									end_IL_0054:
									break;
								}
								break;
							}
						}
						finally
						{
							_200C_200E_206F_200F_200E_202E_200F_206E_202B_206A_206E_200E_206D_200D_200C_200B_200E_200B_206B_202D_206A_206F_202A_206A_206A_206A_202C_202B_202E_206F_206F_200C_206F_200C_206A_200D_200C_202D_202B_202B_202E((IDisposable)enumerator);
						}
						return _206D_202A_202C_200D_200C_202C_200E_200D_206D_202B_206D_206A_206C_206B_202E_202B_206F_200F_202C_206D_202C_206C_206B_202C_206A_206C_202B_202A_206B_202C_206B_206F_206C_206B_206E_206A_202B_202C_202B_200D_202E(text, new char[1] { '#' });
					}
					}
					break;
					IL_002e:
					text = string.Empty;
					num = (int)((num2 * 280334147) ^ 0x67778F8D);
				}
			}
		}
		return string.Empty;
	}

	public static IEnumerable<Buff> Parse(string content)
	{
		string text = default(string);
		string[] array2 = default(string[]);
		int num3 = default(int);
		string[] array3 = default(string[]);
		string[] array = default(string[]);
		int level = default(int);
		int round = default(int);
		string name = default(string);
		int property = default(int);
		while (true)
		{
			int num = -872212498;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ -2036725521)) % 26)
				{
				case 16u:
					break;
				case 24u:
					num = ((!_200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E._206D_206E_202E_206E_200D_206A_200B_200D_202A_206E_206C_200C_202E_206C_200D_206E_200C_200D_200E_202C_202A_200B_200B_200F_200F_202E_202A_200E_200F_200E_200E_206E_202E_200C_200C_202B_200C_200F_200D_200C_202E(content)) ? (-1987292898) : (-1074967681));
					continue;
				case 0u:
					text = array2[num3];
					num = -1550504670;
					continue;
				case 5u:
					array3 = _200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E._200B_206C_206B_200C_200D_200B_200F_200C_200E_206A_206B_206D_206E_200C_202A_202A_200E_202C_206E_202A_200C_206C_200B_206D_206D_200C_206A_206C_206F_202E_206E_200D_202D_202C_200B_202B_206A_200B_200C_202B_202E(content, new char[1] { '#' });
					num = -1973591743;
					continue;
				case 2u:
					num = (int)(num2 * 1757462516) ^ -2046092710;
					continue;
				case 7u:
				{
					uint num4;
					switch (num4)
					{
					case 0u:
						break;
					default:
						goto IL_0114;
					case 1u:
						goto IL_0260;
					}
					goto case 24u;
				}
				case 21u:
					num = ((array.Length > 2) ? (-693185405) : (-1620585814)) ^ ((int)num2 * -193763189);
					continue;
				case 25u:
					yield break;
				case 8u:
					num = (int)(num2 * 595201312) ^ -91118948;
					continue;
				case 15u:
					num = ((int)num2 * -223486168) ^ 0x65F2EF30;
					continue;
				case 6u:
					level = 1;
					num = (int)(num2 * 1198294967) ^ -1687819015;
					continue;
				case 22u:
					round = 3;
					num = (int)((num2 * 58326299) ^ 0x32DA074D);
					continue;
				case 10u:
					yield return new Buff
					{
						Name = name,
						Level = level,
						Round = round,
						Property = property
					};
					/*Error: Unable to find new state assignment for yield return*/;
				case 9u:
					array = _200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E._200B_206C_206B_200C_200D_200B_200F_200C_200E_206A_206B_206D_206E_200C_202A_202A_200E_202C_206E_202A_200C_206C_200B_206D_206D_200C_206A_206C_206F_202E_206E_200D_202D_202C_200B_202B_206A_200B_200C_202B_202E(text, new char[1] { '.' });
					name = array[0];
					num = (int)(num2 * 1562365294) ^ -608717677;
					continue;
				case 18u:
					property = -1;
					num = ((array.Length <= 1) ? (-1297220147) : (-1209393270)) ^ (int)(num2 * 775974378);
					continue;
				case 13u:
					goto IL_0260;
				case 23u:
					num = ((num3 >= array2.Length) ? (-1874406669) : (-747385741));
					continue;
				case 19u:
					/*Error near IL_029d: Unexpected return in MoveNext()*/;
				case 4u:
					num = ((int)num2 * -593038553) ^ 0x7A53A4F8;
					continue;
				case 20u:
					num = (int)(num2 * 370076964) ^ -42087944;
					continue;
				case 3u:
					property = _200B_206A_202E_206C_200B_200B_202C_200E_202A_206B_200C_200F_200F_206D_206E_206A_206D_206A_206A_200F_206A_200D_206C_206F_200F_206B_206B_206F_206C_202A_202B_200D_202A_200E_206C_202A_200B_202C_206B_202E._206E_206C_206C_206E_200E_202A_200D_206C_206D_200C_200B_200B_202C_200D_202C_200C_206C_200B_206F_206F_206A_202A_202A_202E_202A_202D_202C_200C_206F_202A_200D_202A_206A_200D_202A_200D_206F_200E_206F_206A_202E(int.Parse(array[3]), 100);
					num = (int)((num2 * 1277181954) ^ 0x23BE93AF);
					continue;
				case 11u:
					level = int.Parse(array[1]);
					num = ((int)num2 * -1978935064) ^ 0x3254B19E;
					continue;
				case 17u:
					num = ((int)num2 * -1893847105) ^ -1057356772;
					continue;
				case 12u:
					array2 = array3;
					num3 = 0;
					num = (int)((num2 * 463539029) ^ 0x3A24CF99);
					continue;
				case 1u:
					round = int.Parse(array[2]);
					num = ((array.Length <= 3) ? 313999927 : 322402986) ^ (int)(num2 * 1432055026);
					continue;
				default:
					yield break;
				case 14u:
					yield break;
					IL_0114:
					num = ((int)num2 * -1733414791) ^ 0x298DE8D;
					continue;
					IL_0260:
					num3++;
					num = -1460340326;
					continue;
				}
				break;
			}
		}
	}

	public static void SetBuffs()
	{
		BuffNames = null;
		DebuffNames = null;
		while (true)
		{
			int num = 892925089;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x31126DE4)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_002e;
				case 2u:
					return;
				}
				break;
				IL_002e:
				BuffNames = LuaManager.GetConfig<string[]>(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(3160727897u));
				DebuffNames = LuaManager.GetConfig<string[]>(global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(430567616u));
				num = (int)((num2 * 82980441) ^ 0x6915B819);
			}
		}
	}

	static string _200B_206A_202E_202D_206B_206E_202A_206E_200C_206D_206D_200F_202B_200D_202D_200D_206D_202B_202A_200E_206C_202E_206D_202E_206B_206C_202A_202D_200E_200B_202E_200C_202C_202A_206F_206E_206A_202D_206C_206A_202E(string P_0, object[] P_1)
	{
		return string.Format(P_0, P_1);
	}

	static string _206D_206E_206F_206C_206E_200E_200D_200B_202A_202E_202D_202E_206A_200F_200D_202D_206E_202B_206E_206E_200D_202C_200E_202B_206B_200F_206E_206E_206A_202E_206E_206A_200B_202A_206A_200B_200B_202C_202A_206F_202E(string P_0, string P_1)
	{
		return P_0 + P_1;
	}

	static void _200C_200E_206F_200F_200E_202E_200F_206E_202B_206A_206E_200E_206D_200D_200C_200B_200E_200B_206B_202D_206A_206F_202A_206A_206A_206A_202C_202B_202E_206F_206F_200C_206F_200C_206A_200D_200C_202D_202B_202B_202E(IDisposable P_0)
	{
		P_0.Dispose();
	}

	static string _206D_202A_202C_200D_200C_202C_200E_200D_206D_202B_206D_206A_206C_206B_202E_202B_206F_200F_202C_206D_202C_206C_206B_202C_206A_206C_202B_202A_206B_202C_206B_206F_206C_206B_206E_206A_202B_202C_202B_200D_202E(string P_0, char[] P_1)
	{
		return P_0.TrimStart(P_1);
	}

	static bool _206D_202D_206F_202A_206A_202C_206D_200B_200B_206D_202D_202C_206F_202E_202A_200F_206B_206A_206C_206F_202D_200C_202C_202E_200D_202E_200D_206D_202A_202D_206B_206F_206A_206E_202A_206A_202E_202D_202D_206E_202E(string P_0, string P_1)
	{
		return P_0.Equals(P_1);
	}
}
