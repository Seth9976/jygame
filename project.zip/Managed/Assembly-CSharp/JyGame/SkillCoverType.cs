namespace JyGame;

public enum SkillCoverType
{
	NORMAL,
	CROSS,
	STAR,
	LINE,
	FACE,
	FAN,
	RING,
	X,
	FRONT
}
