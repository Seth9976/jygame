namespace JyGame;

public enum AttackCastInfoType
{
	SMALL_DIALOG,
	ATTACK_TEXT
}
