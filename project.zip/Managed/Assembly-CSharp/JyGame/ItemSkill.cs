namespace JyGame;

public class ItemSkill
{
	public bool IsInternal;

	public string SkillName;

	public int MaxLevel;
}
