namespace JyGame;

public enum BattleType
{
	Common,
	Tower,
	Trial,
	Huashan,
	Arena,
	Zhenlongqiju
}
