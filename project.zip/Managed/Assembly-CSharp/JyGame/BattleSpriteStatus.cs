namespace JyGame;

public enum BattleSpriteStatus
{
	Standing,
	Moving,
	PreAttack,
	BeAttack,
	Attacking,
	NoState
}
