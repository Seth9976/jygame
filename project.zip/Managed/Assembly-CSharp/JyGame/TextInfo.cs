using UnityEngine;

namespace JyGame;

public class TextInfo
{
	public string text;

	public Color color;

	public TextInfo(string P_0, Color P_1)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		text = P_0;
		color = P_1;
	}
}
