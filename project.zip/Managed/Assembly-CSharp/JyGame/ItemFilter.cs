namespace JyGame;

public enum ItemFilter
{
	All,
	Zhuangbei,
	Miji,
	Costa,
	Special,
	Mission
}
