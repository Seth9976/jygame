namespace JyGame;

public enum BattleBlockStatus
{
	Hide,
	Normal,
	HighLightGreen,
	HighLightRed,
	HighLightBlue
}
