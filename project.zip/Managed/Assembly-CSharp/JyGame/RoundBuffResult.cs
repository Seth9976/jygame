namespace JyGame;

public class RoundBuffResult
{
	public int AddHp;

	public int AddMp;

	public int AddBall;

	public BuffInstance buff;
}
