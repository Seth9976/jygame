namespace JyGame;

public class AttributeFinalHelper
{
	private Role owner;

	public int this[string key]
	{
		get
		{
			if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(3612748796u)))
			{
				goto IL_0015;
			}
			int num = 1;
			goto IL_0246;
			IL_0242:
			num = 0;
			goto IL_0246;
			IL_0015:
			int num2 = 1347109703;
			goto IL_001a;
			IL_001a:
			int num4 = default(int);
			bool flag = default(bool);
			while (true)
			{
				uint num3;
				switch ((num3 = (uint)(num2 ^ 0x6419838D)) % 92)
				{
				case 34u:
					break;
				case 74u:
					num4 = (int)((double)num4 * 1.05);
					num2 = ((int)num3 * -1074723644) ^ -2048986214;
					continue;
				case 81u:
				{
					int num45;
					int num46;
					if (!owner.HasTalent(ResourceStrings.ResStrings[1256]))
					{
						num45 = -876268972;
						num46 = num45;
					}
					else
					{
						num45 = -347826040;
						num46 = num45;
					}
					num2 = num45 ^ (int)(num3 * 457908863);
					continue;
				}
				case 70u:
					goto IL_01f7;
				case 90u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)(num3 * 1200617680) ^ -25129338;
					continue;
				case 22u:
					goto IL_0242;
				case 48u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)(num3 * 2030050395) ^ -563605411;
					continue;
				case 54u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)(num3 * 108689642) ^ -1381425477;
					continue;
				case 20u:
					goto IL_029e;
				case 57u:
					return num4;
				case 58u:
					goto IL_02da;
				case 28u:
					return num4;
				case 59u:
				{
					int num43;
					int num44;
					if (owner.HasTalent(ResourceStrings.ResStrings[316]))
					{
						num43 = 1307266974;
						num44 = num43;
					}
					else
					{
						num43 = 1836030468;
						num44 = num43;
					}
					num2 = num43 ^ (int)(num3 * 1931387167);
					continue;
				}
				case 18u:
					goto IL_034e;
				case 27u:
					num4 = (int)((double)num4 * 1.15);
					num2 = ((int)num3 * -1929210291) ^ 0x6A28449B;
					continue;
				case 0u:
					num2 = ((int)num3 * -282569926) ^ 0x7ABEF3C1;
					continue;
				case 53u:
					return num4;
				case 8u:
				{
					int num33;
					int num34;
					if (owner.HasTalent(ResourceStrings.ResStrings[1258]))
					{
						num33 = 1264533689;
						num34 = num33;
					}
					else
					{
						num33 = 1094382122;
						num34 = num33;
					}
					num2 = num33 ^ ((int)num3 * -1704062482);
					continue;
				}
				case 11u:
					num4 = (int)((double)num4 * 1.15);
					num2 = (int)(num3 * 1519781218) ^ -789154136;
					continue;
				case 33u:
					return (int)((double)num4 * 1.15);
				case 51u:
					num4 = (int)((double)num4 * 1.2);
					num2 = (int)(num3 * 675946737) ^ -99787807;
					continue;
				case 88u:
					goto IL_0454;
				case 49u:
					goto IL_047a;
				case 75u:
					goto IL_04a0;
				case 82u:
					num4 = (int)((double)num4 * 1.05);
					num2 = ((int)num3 * -1933368614) ^ -624261872;
					continue;
				case 23u:
					goto IL_04e6;
				case 14u:
				{
					int num15;
					int num16;
					if (!owner.HasTalent(ResourceStrings.ResStrings[1257]))
					{
						num15 = -1445726058;
						num16 = num15;
					}
					else
					{
						num15 = -538423104;
						num16 = num15;
					}
					num2 = num15 ^ (int)(num3 * 519654389);
					continue;
				}
				case 42u:
				{
					int num7;
					int num8;
					if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(3535376985u)))
					{
						num7 = -146887468;
						num8 = num7;
					}
					else
					{
						num7 = -599789217;
						num8 = num7;
					}
					num2 = num7 ^ ((int)num3 * -2133098309);
					continue;
				}
				case 13u:
				{
					int num37;
					int num38;
					if (owner.HasTalent(ResourceStrings.ResStrings[1258]))
					{
						num37 = -1082871951;
						num38 = num37;
					}
					else
					{
						num37 = -1215008170;
						num38 = num37;
					}
					num2 = num37 ^ ((int)num3 * -1977934081);
					continue;
				}
				case 24u:
					num4 = (int)((double)num4 * 1.2);
					num2 = ((int)num3 * -1106504709) ^ 0x64948574;
					continue;
				case 43u:
					return num4;
				case 32u:
					goto IL_05de;
				case 64u:
				{
					int num29;
					int num30;
					if (owner.HasTalent(ResourceStrings.ResStrings[296]))
					{
						num29 = -1919955823;
						num30 = num29;
					}
					else
					{
						num29 = -266035784;
						num30 = num29;
					}
					num2 = num29 ^ (int)(num3 * 342042937);
					continue;
				}
				case 84u:
				{
					int num25;
					int num26;
					if (!owner.BuiltInTalents[144])
					{
						num25 = -69549190;
						num26 = num25;
					}
					else
					{
						num25 = -841806608;
						num26 = num25;
					}
					num2 = num25 ^ ((int)num3 * -443024174);
					continue;
				}
				case 44u:
					goto IL_0665;
				case 9u:
					goto IL_0685;
				case 85u:
				{
					int num21;
					int num22;
					if (!owner.BuiltInTalents[135])
					{
						num21 = 744324483;
						num22 = num21;
					}
					else
					{
						num21 = 1714164895;
						num22 = num21;
					}
					num2 = num21 ^ ((int)num3 * -931484363);
					continue;
				}
				case 45u:
					goto IL_06de;
				case 10u:
					goto IL_0704;
				case 62u:
					return num4;
				case 41u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)((num3 * 405938259) ^ 0x722A2081);
					continue;
				case 1u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)(num3 * 1077686166) ^ -1308930143;
					continue;
				case 67u:
					goto IL_0776;
				case 29u:
					goto IL_078d;
				case 72u:
				{
					int num11;
					int num12;
					if (owner.HasTalent(ResourceStrings.ResStrings[297]))
					{
						num11 = 535142386;
						num12 = num11;
					}
					else
					{
						num11 = 1310228787;
						num12 = num11;
					}
					num2 = num11 ^ (int)(num3 * 724780140);
					continue;
				}
				case 7u:
					return num4;
				case 68u:
					goto IL_0801;
				case 76u:
					return num4;
				case 38u:
					num4 = owner.Attributes[key] + owner.GetAdditionAttribute(key);
					num2 = 740400105;
					continue;
				case 61u:
					return (int)((double)num4 * 1.05);
				case 86u:
				{
					int num41;
					int num42;
					if (!owner.HasTalent(ResourceStrings.ResStrings[1257]))
					{
						num41 = 409733752;
						num42 = num41;
					}
					else
					{
						num41 = 86055414;
						num42 = num41;
					}
					num2 = num41 ^ (int)(num3 * 1391273489);
					continue;
				}
				case 5u:
				{
					int num39;
					int num40;
					if (owner.HasTalent(ResourceStrings.ResStrings[317]))
					{
						num39 = 456623897;
						num40 = num39;
					}
					else
					{
						num39 = 966959275;
						num40 = num39;
					}
					num2 = num39 ^ (int)(num3 * 627645302);
					continue;
				}
				case 91u:
					goto IL_08ee;
				case 73u:
					return num4;
				case 31u:
					goto IL_092a;
				case 69u:
				{
					int num35;
					int num36;
					if (CommonSettings.MOD_KEY() != 2)
					{
						num35 = -1365868965;
						num36 = num35;
					}
					else
					{
						num35 = -2037140741;
						num36 = num35;
					}
					num2 = num35 ^ (int)(num3 * 95988264);
					continue;
				}
				case 37u:
				{
					int num31;
					int num32;
					if (owner.HasTalent(ResourceStrings.ResStrings[1256]))
					{
						num31 = -544827555;
						num32 = num31;
					}
					else
					{
						num31 = -1677675383;
						num32 = num31;
					}
					num2 = num31 ^ ((int)num3 * -641686041);
					continue;
				}
				case 12u:
					goto IL_09ac;
				case 83u:
					goto IL_09d2;
				case 50u:
					return (int)((double)num4 * 1.05);
				case 6u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)((num3 * 1299383115) ^ 0x1B7C166F);
					continue;
				case 26u:
					return num4;
				case 66u:
				{
					int num27;
					int num28;
					if (owner.HasTalent(ResourceStrings.ResStrings[296]))
					{
						num27 = -1430141448;
						num28 = num27;
					}
					else
					{
						num27 = -1586929205;
						num28 = num27;
					}
					num2 = num27 ^ (int)(num3 * 2050394413);
					continue;
				}
				case 19u:
					goto IL_0a7e;
				case 30u:
					return num4;
				case 77u:
					goto IL_0ab0;
				case 15u:
					goto IL_0adb;
				case 78u:
					return (int)((double)num4 * 1.05);
				case 17u:
				{
					int num23;
					int num24;
					if (!owner.HasTalent(ResourceStrings.ResStrings[1292]))
					{
						num23 = 1182712881;
						num24 = num23;
					}
					else
					{
						num23 = 607704830;
						num24 = num23;
					}
					num2 = num23 ^ (int)(num3 * 1808502318);
					continue;
				}
				case 47u:
					num4 = (int)((double)num4 * 1.1);
					num2 = (int)((num3 * 349196600) ^ 0x6933958E);
					continue;
				case 36u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)(num3 * 722173392) ^ -531137928;
					continue;
				case 80u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)((num3 * 1320639066) ^ 0x237A4B15);
					continue;
				case 63u:
					num4 = (int)((double)num4 * 1.1);
					num2 = ((int)num3 * -1111655042) ^ -1350783874;
					continue;
				case 16u:
					goto IL_0be0;
				case 52u:
					goto IL_0bf7;
				case 40u:
				{
					int num19;
					int num20;
					if (!owner.BuiltInTalents[135])
					{
						num19 = 960568657;
						num20 = num19;
					}
					else
					{
						num19 = 443655692;
						num20 = num19;
					}
					num2 = num19 ^ (int)(num3 * 2004476017);
					continue;
				}
				case 79u:
					num4 = owner.GetMaxSkillTypeValue2() + owner.GetAdditionAttribute(global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(1706514926u));
					num2 = ((int)num3 * -1721870442) ^ 0xF5BFE43;
					continue;
				case 71u:
					num4 = (int)((double)num4 * 1.1);
					num2 = ((int)num3 * -1691373480) ^ 0x7DE40FCB;
					continue;
				case 25u:
					goto IL_0ca9;
				case 39u:
					return num4;
				case 4u:
					return (int)((double)num4 * 1.15);
				case 21u:
					num4 = (int)((double)num4 * 1.2);
					num2 = ((int)num3 * -890002339) ^ -1925780260;
					continue;
				case 2u:
					num4 = (int)((double)num4 * 1.1);
					num2 = ((int)num3 * -1804020716) ^ 0x66D4E6F7;
					continue;
				case 3u:
					num4 = (int)((double)num4 * 1.05);
					num2 = (int)((num3 * 445650392) ^ 0x41D95B2F);
					continue;
				case 55u:
					num4 = (int)((double)num4 * 1.2);
					num2 = (int)(num3 * 1567804767) ^ -992676768;
					continue;
				case 35u:
				{
					int num17;
					int num18;
					if (!owner.BuiltInTalents[136])
					{
						num17 = 707250261;
						num18 = num17;
					}
					else
					{
						num17 = 980054183;
						num18 = num17;
					}
					num2 = num17 ^ (int)(num3 * 1430394763);
					continue;
				}
				case 56u:
				{
					int num13;
					int num14;
					if (!owner.BuiltInTalents[152])
					{
						num13 = 1656931174;
						num14 = num13;
					}
					else
					{
						num13 = 1553848059;
						num14 = num13;
					}
					num2 = num13 ^ ((int)num3 * -713142940);
					continue;
				}
				case 65u:
				{
					int num9;
					int num10;
					if (owner.BuiltInTalents[143])
					{
						num9 = 867029922;
						num10 = num9;
					}
					else
					{
						num9 = 1129171192;
						num10 = num9;
					}
					num2 = num9 ^ (int)(num3 * 1417361574);
					continue;
				}
				case 87u:
					return num4;
				case 89u:
				{
					int num5;
					int num6;
					if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(430829805u)))
					{
						num5 = -1353040149;
						num6 = num5;
					}
					else
					{
						num5 = -592253972;
						num6 = num5;
					}
					num2 = num5 ^ (int)(num3 * 1162342431);
					continue;
				}
				case 60u:
					return num4;
				default:
					return num4;
				}
				break;
				IL_0ca9:
				int num47;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(394181284u)))
				{
					num2 = 351166009;
					num47 = num2;
				}
				else
				{
					num2 = 228419209;
					num47 = num2;
				}
				continue;
				IL_04e6:
				int num48;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(1940200750u)))
				{
					num2 = 822703847;
					num48 = num2;
				}
				else
				{
					num2 = 686363876;
					num48 = num2;
				}
				continue;
				IL_08ee:
				int num49;
				if (!owner.HasTalent(ResourceStrings.ResStrings[314]))
				{
					num2 = 2102382493;
					num49 = num2;
				}
				else
				{
					num2 = 1376247385;
					num49 = num2;
				}
				continue;
				IL_0bf7:
				int num50;
				if (!owner.BuiltInTalents[142])
				{
					num2 = 1950428487;
					num50 = num2;
				}
				else
				{
					num2 = 614527898;
					num50 = num2;
				}
				continue;
				IL_029e:
				int num51;
				if (!owner.HasTalent(ResourceStrings.ResStrings[315]))
				{
					num2 = 1347065703;
					num51 = num2;
				}
				else
				{
					num2 = 1885268219;
					num51 = num2;
				}
				continue;
				IL_0685:
				int num52;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(942219431u)))
				{
					num2 = 245037960;
					num52 = num2;
				}
				else
				{
					num2 = 1813532845;
					num52 = num2;
				}
				continue;
				IL_0be0:
				int num53;
				if (!flag)
				{
					num2 = 200618391;
					num53 = num2;
				}
				else
				{
					num2 = 1465708396;
					num53 = num2;
				}
				continue;
				IL_0801:
				int num54;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(1944260873u)))
				{
					num2 = 86351569;
					num54 = num2;
				}
				else
				{
					num2 = 2089343972;
					num54 = num2;
				}
				continue;
				IL_0454:
				int num55;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(1029863417u)))
				{
					num2 = 692774023;
					num55 = num2;
				}
				else
				{
					num2 = 75192786;
					num55 = num2;
				}
				continue;
				IL_0adb:
				int num56;
				if (owner.BuiltInTalents[142])
				{
					num2 = 1233301347;
					num56 = num2;
				}
				else
				{
					num2 = 162487228;
					num56 = num2;
				}
				continue;
				IL_04a0:
				int num57;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(2981046594u)))
				{
					num2 = 506925797;
					num57 = num2;
				}
				else
				{
					num2 = 645358634;
					num57 = num2;
				}
				continue;
				IL_078d:
				int num58;
				if (!owner.HasTalent(ResourceStrings.ResStrings[315]))
				{
					num2 = 128050901;
					num58 = num2;
				}
				else
				{
					num2 = 14076309;
					num58 = num2;
				}
				continue;
				IL_0ab0:
				int num59;
				if (owner.BuiltInTalents[141])
				{
					num2 = 1166386067;
					num59 = num2;
				}
				else
				{
					num2 = 1005311141;
					num59 = num2;
				}
				continue;
				IL_0665:
				int num60;
				if (RuntimeData.Instance.isBattle)
				{
					num2 = 2032666800;
					num60 = num2;
				}
				else
				{
					num2 = 828854389;
					num60 = num2;
				}
				continue;
				IL_01f7:
				int num61;
				if (!owner.BuiltInTalents[141])
				{
					num2 = 1662501176;
					num61 = num2;
				}
				else
				{
					num2 = 1911995081;
					num61 = num2;
				}
				continue;
				IL_0a7e:
				int num62;
				if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(1029863417u)))
				{
					num2 = 1530764438;
					num62 = num2;
				}
				else
				{
					num2 = 225254784;
					num62 = num2;
				}
				continue;
				IL_0776:
				int num63;
				if (flag)
				{
					num2 = 1485609741;
					num63 = num2;
				}
				else
				{
					num2 = 200618391;
					num63 = num2;
				}
				continue;
				IL_02da:
				int num64;
				if (!owner.HasTalent(ResourceStrings.ResStrings[314]))
				{
					num2 = 1437450226;
					num64 = num2;
				}
				else
				{
					num2 = 259714487;
					num64 = num2;
				}
				continue;
				IL_09d2:
				int num65;
				if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(4176639349u)))
				{
					num2 = 645358634;
					num65 = num2;
				}
				else
				{
					num2 = 420892301;
					num65 = num2;
				}
				continue;
				IL_05de:
				int num66;
				if (CommonSettings.MOD_KEY() == 2)
				{
					num2 = 212113436;
					num66 = num2;
				}
				else
				{
					num2 = 2103423436;
					num66 = num2;
				}
				continue;
				IL_0704:
				int num67;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(2053407229u)))
				{
					num2 = 826847662;
					num67 = num2;
				}
				else
				{
					num2 = 1586191846;
					num67 = num2;
				}
				continue;
				IL_09ac:
				int num68;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(2981046594u)))
				{
					num2 = 1075181012;
					num68 = num2;
				}
				else
				{
					num2 = 1813532845;
					num68 = num2;
				}
				continue;
				IL_047a:
				int num69;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(2053407229u)))
				{
					num2 = 8130388;
					num69 = num2;
				}
				else
				{
					num2 = 1824825682;
					num69 = num2;
				}
				continue;
				IL_034e:
				int num70;
				if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(248942232u)))
				{
					num2 = 833539747;
					num70 = num2;
				}
				else
				{
					num2 = 2049480712;
					num70 = num2;
				}
				continue;
				IL_092a:
				int num71;
				if (!_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(2722506620u)))
				{
					num2 = 199027969;
					num71 = num2;
				}
				else
				{
					num2 = 523885704;
					num71 = num2;
				}
				continue;
				IL_06de:
				int num72;
				if (_200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(key, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(2223184606u)))
				{
					num2 = 1087064138;
					num72 = num2;
				}
				else
				{
					num2 = 594497053;
					num72 = num2;
				}
			}
			goto IL_0015;
			IL_0246:
			flag = (byte)num != 0;
			int num73;
			if (flag)
			{
				num2 = 906762418;
				num73 = num2;
			}
			else
			{
				num2 = 1310189179;
				num73 = num2;
			}
			goto IL_001a;
		}
	}

	public AttributeFinalHelper(Role P_0)
	{
		owner = P_0;
	}

	static bool _200D_200B_206B_206C_200B_200B_202D_202B_200C_206C_206D_202D_202A_206C_200E_200E_202C_206D_206E_206B_206D_202E_206C_206D_202A_200E_202B_206A_202D_202D_206D_202E_200F_202A_206B_206C_200C_206C_202C_202A_202E(string P_0, string P_1)
	{
		return P_0 == P_1;
	}
}
