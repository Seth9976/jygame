namespace JyGame;

public enum ItemType
{
	Costa,
	Weapon,
	Armor,
	Accessories,
	Book,
	Mission,
	SpeicalSkillBook,
	TalentBook,
	Upgrade,
	Special,
	Canzhang,
	SwitchGameScene,
	Book2,
	SwitchGameScene2,
	HiddenWeapon
}
