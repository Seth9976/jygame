namespace JyGame;

public enum SkillCode
{
	Quanzhang,
	Jianfa,
	Daofa,
	Qimen
}
