namespace JyGame;

public class MoveSearchHelper
{
	public int X;

	public int Y;

	public int Cost;

	public MoveSearchHelper front;
}
