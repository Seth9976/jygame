using UnityEngine;

namespace JyGame;

public class AssetBundleUnit
{
	public string name;

	public string info;

	public AssetBundle asset;
}
