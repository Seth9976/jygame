namespace JyGame;

public enum SkillType
{
	Normal,
	Internal,
	Unique,
	Special,
	Aoyi,
	yuliu5,
	yuliu6,
	yuliu7,
	Title
}
