namespace JyGame;

public class AttackFormula
{
	public double attackLow;

	public double attackUp;

	public double criticalHit;

	public double defence;
}
