namespace JyGame;

public class AIResult
{
	public int MoveX;

	public int MoveY;

	public SkillBox skill;

	public int AttackX;

	public int AttackY;

	public bool IsRest;

	public int totalAttackComputeNum;
}
