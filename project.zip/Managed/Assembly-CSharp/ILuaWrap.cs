public interface ILuaWrap
{
	void Register();
}
