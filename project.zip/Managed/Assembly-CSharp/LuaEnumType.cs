public enum LuaEnumType
{
	AAA = 1,
	BBB,
	CCC,
	DDD
}
