public enum ShopType
{
	SHOP,
	XIANGZI
}
