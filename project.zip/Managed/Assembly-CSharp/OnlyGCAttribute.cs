using System;

public class OnlyGCAttribute : Attribute
{
}
