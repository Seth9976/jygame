using System;

internal class ConfusedByAttribute : Attribute
{
	public ConfusedByAttribute(string P_0)
	{
	}
}
