using System;
using UnityEngine;

public class TestEventListener : MonoBehaviour
{
	public Action<GameObject> OnClick;
}
