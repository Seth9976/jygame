public enum RoleSelectMenuMode
{
	BattleSelectMode,
	RoleSelectMode
}
