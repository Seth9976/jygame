public enum ItemDetailMode
{
	Usable,
	Selectable,
	DropEquipped,
	Disable,
	Equipable,
	Studiable,
	Sellable,
	UsableCanzhang
}
