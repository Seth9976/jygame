using System;

public class NoToLuaAttribute : Attribute
{
}
