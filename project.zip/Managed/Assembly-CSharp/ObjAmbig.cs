public enum ObjAmbig
{
	None,
	U3dObj,
	NetObj,
	All
}
