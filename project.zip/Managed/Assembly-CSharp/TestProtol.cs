public static class TestProtol
{
	public static LuaStringBuffer data;
}
