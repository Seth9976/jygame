public enum ShopStatus
{
	BUY,
	SELL,
	XIANGZI_GET,
	XIANGZI_PUT
}
