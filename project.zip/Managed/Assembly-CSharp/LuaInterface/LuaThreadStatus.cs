namespace LuaInterface;

public enum LuaThreadStatus
{
	LUA_YIELD = 1,
	LUA_ERRRUN,
	LUA_ERRSYNTAX,
	LUA_ERRMEM,
	LUA_ERRERR
}
