namespace LuaInterface;

public interface ILuaGeneratedType
{
	LuaTable __luaInterface_getLuaTable();
}
