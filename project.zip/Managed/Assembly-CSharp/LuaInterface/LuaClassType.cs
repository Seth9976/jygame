using System;

namespace LuaInterface;

internal struct LuaClassType
{
	public Type klass;

	public Type[][] returnTypes;
}
