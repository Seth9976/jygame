namespace LuaInterface;

public delegate byte[] ReadLuaFile(string name);
