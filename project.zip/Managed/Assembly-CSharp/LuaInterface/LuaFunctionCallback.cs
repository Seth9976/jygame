using System;

namespace LuaInterface;

public delegate int LuaFunctionCallback(IntPtr luaState);
