namespace LuaInterface;

public struct ReaderInfo
{
	public string chunkData;

	public bool finished;
}
