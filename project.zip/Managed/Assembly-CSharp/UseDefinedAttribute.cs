using System;

public class UseDefinedAttribute : Attribute
{
}
