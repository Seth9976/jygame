public enum MetaOp
{
	None = 0,
	Add = 1,
	Sub = 2,
	Mul = 4,
	Div = 8,
	Eq = 16,
	Neg = 32,
	ALL = 63
}
