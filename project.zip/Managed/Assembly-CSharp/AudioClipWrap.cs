using System;
using System.Runtime.CompilerServices;
using LuaInterface;
using UnityEngine;

public class AudioClipWrap
{
	[CompilerGenerated]
	private sealed class _206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E
	{
		internal IntPtr L;
	}

	[CompilerGenerated]
	private sealed class _200B_200F_202B_206D_202D_206C_202D_202B_206E_200B_202C_200B_206D_202E_206D_202A_206D_200E_206A_206D_206A_206B_206F_206A_200E_202B_202E_202B_202E_206A_202E_200E_206E_202B_202D_202E_202A_200B_200D_202A_202E
	{
		internal LuaFunction func;

		internal _206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E _202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E;

		internal void _206B_206A_202A_206D_200D_206D_206C_200E_200E_200C_206E_200D_202B_200F_202B_206E_206B_200B_206C_206D_200C_206E_200E_202D_200D_202A_206F_206F_206C_202A_202A_202B_202B_206D_200F_200F_202A_200F_200D_200F_202E(float[] P_0)
		{
			int oldTop = func.BeginPCall();
			LuaScriptMgr.PushArray(_202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E.L, P_0);
			while (true)
			{
				int num = -360760901;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ -1470029471)) % 3)
					{
					case 0u:
						break;
					default:
						return;
					case 2u:
						goto IL_003f;
					case 1u:
						return;
					}
					break;
					IL_003f:
					func.PCall(oldTop, 1);
					func.EndPCall(oldTop);
					num = (int)((num2 * 718779802) ^ 0x42AAC6C8);
				}
			}
		}
	}

	[CompilerGenerated]
	private sealed class _200B_200E_200C_202A_206E_202D_206C_200B_206F_200B_200D_200E_202D_202A_202E_202A_202C_202C_200C_206C_206D_200E_202B_206B_206F_206A_202C_200E_202C_206D_202E_206D_206E_200F_206D_202D_200B_206F_202E_206F_202E
	{
		internal LuaFunction func;

		internal _206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E _202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E;

		internal void _206E_206A_202E_206D_206E_202C_200C_202A_200F_200B_206A_200F_202E_202E_206C_206F_202D_202A_200D_200F_206F_200B_202E_206B_200B_200C_206B_202B_200E_200E_202A_202E_206D_206B_202B_200E_206D_206A_200B_200E_202E(float[] P_0)
		{
			int oldTop = func.BeginPCall();
			while (true)
			{
				int num = 866767631;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ 0x3B219ADC)) % 5)
					{
					case 0u:
						break;
					default:
						return;
					case 3u:
						LuaScriptMgr.PushArray(_202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E.L, P_0);
						num = ((int)num2 * -301485928) ^ -1740139018;
						continue;
					case 4u:
						func.EndPCall(oldTop);
						num = (int)(num2 * 583143610) ^ -1130777226;
						continue;
					case 1u:
						func.PCall(oldTop, 1);
						num = ((int)num2 * -159653190) ^ -532937183;
						continue;
					case 2u:
						return;
					}
					break;
				}
			}
		}
	}

	[CompilerGenerated]
	private sealed class _202D_202E_200D_206D_202A_206F_206E_202B_202C_202A_200D_202A_202B_202E_202B_206A_200F_206F_206C_202E_200E_202D_202C_200F_206C_206E_202E_202A_202E_206D_206D_200E_200D_200C_200E_206D_202A_200B_206C_202E
	{
		internal LuaFunction func;

		internal _206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E _202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E;

		internal void _200B_200E_206A_200F_202C_200E_200D_206E_206D_206B_206D_202D_200F_206D_206C_200F_200F_200F_202D_202D_202E_200F_202C_206B_206A_200F_206C_200F_206E_200E_206E_200C_200C_206E_200B_202B_200C_206D_206B_202B_202E(int P_0)
		{
			int oldTop = func.BeginPCall();
			while (true)
			{
				int num = -558415960;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ -875059924)) % 3)
					{
					case 0u:
						break;
					default:
						return;
					case 1u:
						goto IL_002e;
					case 2u:
						return;
					}
					break;
					IL_002e:
					LuaScriptMgr.Push(_202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E.L, P_0);
					func.PCall(oldTop, 1);
					func.EndPCall(oldTop);
					num = ((int)num2 * -1789679187) ^ -2042510048;
				}
			}
		}
	}

	private static Type classType = _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(AudioClip).TypeHandle);

	public static void Register(IntPtr L)
	{
		LuaMethod[] regs = new LuaMethod[8]
		{
			new LuaMethod(global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(3026917613u), LoadAudioData),
			new LuaMethod(global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(1135128778u), UnloadAudioData),
			new LuaMethod(global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(1247422827u), GetData),
			new LuaMethod(global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(2613989925u), SetData),
			new LuaMethod(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(974578644u), Create),
			new LuaMethod(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(2254933974u), _200C_200C_202B_200C_200D_200B_200D_202E_200C_202C_206C_202E_202D_206B_202C_200E_200B_206F_202B_202B_206C_200E_200D_202C_200E_202A_202C_200D_202E_206F_200B_200F_202D_200C_206F_202E_206A_202C_202A_200C_202E),
			new LuaMethod(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(10103728u), GetClassType),
			new LuaMethod(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(3747390401u), Lua_Eq)
		};
		LuaField[] fields = new LuaField[8]
		{
			new LuaField(global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(2949167492u), get_length, null),
			new LuaField(global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(2137170220u), get_samples, null),
			new LuaField(global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(3327880626u), get_channels, null),
			new LuaField(global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(3783231353u), get_frequency, null),
			new LuaField(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(533589707u), get_loadType, null),
			new LuaField(global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(3892686137u), get_preloadAudioData, null),
			new LuaField(global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(891011132u), get_loadState, null),
			new LuaField(global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(338896511u), get_loadInBackground, null)
		};
		while (true)
		{
			int num = -854418410;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ -858666010)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_02a8;
				case 2u:
					return;
				}
				break;
				IL_02a8:
				LuaScriptMgr.RegisterLib(L, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(1631986893u), _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(AudioClip).TypeHandle), regs, fields, _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(Object).TypeHandle));
				num = ((int)num2 * -2145642911) ^ -647650464;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int _200C_200C_202B_200C_200D_200B_200D_202E_200C_202C_206C_202E_202D_206B_202C_200E_200B_206F_202B_202B_206C_200E_200D_202C_200E_202A_202C_200D_202E_206F_200B_200F_202D_200C_206F_202E_206A_202C_202A_200C_202E(IntPtr P_0)
	{
		if (LuaDLL.lua_gettop(P_0) == 0)
		{
			while (true)
			{
				int num = -287942035;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ -1970017876)) % 4)
					{
					case 2u:
						break;
					case 1u:
					{
						AudioClip obj = _206B_206D_206C_202C_206F_202B_206D_206E_202C_206E_206F_202E_202D_200E_200C_202C_202B_200B_200F_202A_200E_200D_200B_206A_206F_202E_200F_206C_202A_206B_202D_206A_202C_206A_206D_200B_202E_206D_202C_202B_202E();
						LuaScriptMgr.Push(P_0, (Object)(object)obj);
						num = ((int)num2 * -816124103) ^ 0x7F9767D1;
						continue;
					}
					case 0u:
						return 1;
					default:
						goto end_IL_000a;
					}
					break;
				}
				continue;
				end_IL_000a:
				break;
			}
		}
		LuaDLL.luaL_error(P_0, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(2523922860u));
		return 0;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int GetClassType(IntPtr L)
	{
		LuaScriptMgr.Push(L, classType);
		return 1;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_length(IntPtr L)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = (AudioClip)luaObject;
		if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
		{
			LuaTypes luaTypes = default(LuaTypes);
			while (true)
			{
				int num = 1217851543;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ 0x6CC410D9)) % 7)
					{
					case 2u:
						break;
					case 6u:
						LuaDLL.luaL_error(L, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(7394222u));
						num = (int)((num2 * 1725157310) ^ 0x105239D3);
						continue;
					case 1u:
						LuaDLL.luaL_error(L, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(3648622851u));
						num = 805197602;
						continue;
					case 0u:
						num = (int)((num2 * 1474339484) ^ 0x29F5CFF2);
						continue;
					case 5u:
						luaTypes = LuaDLL.lua_type(L, 1);
						num = (int)((num2 * 1698741328) ^ 0x62CCC004);
						continue;
					case 3u:
					{
						int num3;
						int num4;
						if (luaTypes != LuaTypes.LUA_TTABLE)
						{
							num3 = -313846227;
							num4 = num3;
						}
						else
						{
							num3 = -2077506874;
							num4 = num3;
						}
						num = num3 ^ ((int)num2 * -327565574);
						continue;
					}
					default:
						goto end_IL_001b;
					}
					break;
				}
				continue;
				end_IL_001b:
				break;
			}
		}
		LuaScriptMgr.Push(L, _202B_202D_202C_202D_200E_200E_202C_206F_200C_206C_206F_206A_202A_206F_200C_206B_202C_206E_206E_206C_206C_202A_200B_200C_206C_206D_202A_202E_200B_206B_202D_206F_206C_206A_200B_202A_206B_202C_200D_206A_202E(val));
		return 1;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_samples(IntPtr L)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = (AudioClip)luaObject;
		if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
		{
			goto IL_0018;
		}
		goto IL_0070;
		IL_0018:
		int num = 414138775;
		goto IL_001d;
		IL_001d:
		LuaTypes luaTypes = default(LuaTypes);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)(num ^ 0x66DE6034)) % 8)
			{
			case 0u:
				break;
			case 1u:
				LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(2033210396u));
				num = ((int)num2 * -1910763166) ^ -1245413198;
				continue;
			case 2u:
				goto IL_0070;
			case 3u:
				luaTypes = LuaDLL.lua_type(L, 1);
				num = ((int)num2 * -1578690374) ^ 0x3C1E04E5;
				continue;
			case 4u:
				num = (int)(num2 * 1310497942) ^ -445013218;
				continue;
			case 7u:
			{
				int num3;
				int num4;
				if (luaTypes == LuaTypes.LUA_TTABLE)
				{
					num3 = 999326451;
					num4 = num3;
				}
				else
				{
					num3 = 1641966788;
					num4 = num3;
				}
				num = num3 ^ (int)(num2 * 1193065522);
				continue;
			}
			case 6u:
				LuaDLL.luaL_error(L, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(1343837048u));
				num = 1842004966;
				continue;
			default:
				return 1;
			}
			break;
		}
		goto IL_0018;
		IL_0070:
		LuaScriptMgr.Push(L, _206D_202E_200E_206D_200B_206F_206F_206E_206D_206E_206A_202B_206A_206A_206D_202E_206C_202D_200C_200D_202C_202C_206D_200C_206B_206B_206F_200D_206A_202C_206E_200E_202B_202D_200F_206E_202B_200C_206C_200F_202E(val));
		num = 1484626073;
		goto IL_001d;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_channels(IntPtr L)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = (AudioClip)luaObject;
		if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
		{
			goto IL_0018;
		}
		goto IL_004d;
		IL_0018:
		int num = 1287255523;
		goto IL_001d;
		IL_001d:
		LuaTypes luaTypes = default(LuaTypes);
		while (true)
		{
			uint num2;
			switch ((num2 = (uint)(num ^ 0x34A980DF)) % 7)
			{
			case 5u:
				break;
			case 4u:
				goto IL_004d;
			case 3u:
			{
				int num3;
				int num4;
				if (luaTypes != LuaTypes.LUA_TTABLE)
				{
					num3 = -1469158639;
					num4 = num3;
				}
				else
				{
					num3 = -1799855577;
					num4 = num3;
				}
				num = num3 ^ ((int)num2 * -787813373);
				continue;
			}
			case 6u:
				LuaDLL.luaL_error(L, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(532182913u));
				num = ((int)num2 * -464094136) ^ -853314497;
				continue;
			case 0u:
				LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(2738534392u));
				num = 221863455;
				continue;
			case 1u:
				luaTypes = LuaDLL.lua_type(L, 1);
				num = (int)(num2 * 968081670) ^ -1826325181;
				continue;
			default:
				return 1;
			}
			break;
		}
		goto IL_0018;
		IL_004d:
		LuaScriptMgr.Push(L, _202D_206E_202B_206E_206D_206A_200D_206A_200E_200C_200C_206E_206A_202C_200D_202E_206B_206D_202A_202A_202A_206B_202B_200B_200E_202E_200C_202A_200B_202B_206B_200E_206B_206A_200F_200F_200E_202C_206E_202E(val));
		num = 380000538;
		goto IL_001d;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_frequency(IntPtr L)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = (AudioClip)luaObject;
		while (true)
		{
			int num = 1238308721;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x6E7613CB)) % 7)
				{
				case 0u:
					break;
				case 4u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(3520995767u));
					num = 336970618;
					continue;
				case 3u:
				{
					LuaTypes luaTypes = LuaDLL.lua_type(L, 1);
					int num5;
					int num6;
					if (luaTypes != LuaTypes.LUA_TTABLE)
					{
						num5 = 1223535474;
						num6 = num5;
					}
					else
					{
						num5 = 431742940;
						num6 = num5;
					}
					num = num5 ^ ((int)num2 * -333921949);
					continue;
				}
				case 5u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(1568206939u));
					num = ((int)num2 * -1356131122) ^ 0x8591801;
					continue;
				case 2u:
				{
					int num3;
					int num4;
					if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
					{
						num3 = -1388094052;
						num4 = num3;
					}
					else
					{
						num3 = -1344447768;
						num4 = num3;
					}
					num = num3 ^ ((int)num2 * -610294435);
					continue;
				}
				case 1u:
					num = (int)((num2 * 427039451) ^ 0x61746704);
					continue;
				default:
					LuaScriptMgr.Push(L, _200F_200C_202A_206A_202C_202D_202A_200F_206C_202C_206E_200E_206F_206E_200D_200D_200E_206D_200E_206B_202C_202A_206F_200E_206E_200D_206C_200C_206F_206E_202D_206A_206C_206C_200E_202D_200C_206C_206D_202A_202E(val));
					return 1;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_loadType(IntPtr L)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected O, but got Unknown
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = default(AudioClip);
		while (true)
		{
			int num = 944892378;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x23174EA1)) % 9)
				{
				case 6u:
					break;
				case 3u:
					val = (AudioClip)luaObject;
					num = (int)((num2 * 513401453) ^ 0x37B18C49);
					continue;
				case 4u:
				{
					int num5;
					int num6;
					if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
					{
						num5 = -218746896;
						num6 = num5;
					}
					else
					{
						num5 = -787567717;
						num6 = num5;
					}
					num = num5 ^ (int)(num2 * 2095704636);
					continue;
				}
				case 2u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(297528773u));
					num = 714817407;
					continue;
				case 5u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(2360864984u));
					num = (int)(num2 * 329642533) ^ -1999385182;
					continue;
				case 8u:
				{
					LuaTypes luaTypes = LuaDLL.lua_type(L, 1);
					int num3;
					int num4;
					if (luaTypes != LuaTypes.LUA_TTABLE)
					{
						num3 = 903711698;
						num4 = num3;
					}
					else
					{
						num3 = 2070942295;
						num4 = num3;
					}
					num = num3 ^ ((int)num2 * -814687052);
					continue;
				}
				case 7u:
					LuaScriptMgr.Push(L, (Enum)(object)_206A_206B_200E_206F_200B_200E_200D_202D_206B_200C_200E_200E_200E_202E_202E_206D_200E_206A_206A_206D_206E_206A_206F_206F_200F_206F_200D_202B_206F_200F_206A_206A_206B_202E_202B_206D_202B_200C_202C_202B_202E(val));
					num = 1656726207;
					continue;
				case 0u:
					num = ((int)num2 * -819744524) ^ -1638837461;
					continue;
				default:
					return 1;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_preloadAudioData(IntPtr L)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = default(AudioClip);
		while (true)
		{
			int num = 986482235;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x4A54C60)) % 6)
				{
				case 4u:
					break;
				case 5u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(2911095752u));
					num = (int)(num2 * 774449497) ^ -1886717479;
					continue;
				case 3u:
				{
					LuaTypes luaTypes = LuaDLL.lua_type(L, 1);
					int num5;
					int num6;
					if (luaTypes != LuaTypes.LUA_TTABLE)
					{
						num5 = 56255194;
						num6 = num5;
					}
					else
					{
						num5 = 2080953879;
						num6 = num5;
					}
					num = num5 ^ ((int)num2 * -88986570);
					continue;
				}
				case 1u:
				{
					val = (AudioClip)luaObject;
					int num3;
					int num4;
					if (!_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
					{
						num3 = 1599993580;
						num4 = num3;
					}
					else
					{
						num3 = 144470433;
						num4 = num3;
					}
					num = num3 ^ ((int)num2 * -1554694548);
					continue;
				}
				case 2u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(1204432004u));
					num = 1267179144;
					continue;
				default:
					LuaScriptMgr.Push(L, _200B_202A_206A_202C_202C_202C_206A_202A_200E_202E_200B_202E_202B_200D_206B_202C_200B_200C_202B_202C_200B_202C_200E_200C_200F_200D_206E_202B_200C_202C_200C_206E_206F_202B_202D_200F_202B_202D_202D_202E(val));
					return 1;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_loadState(IntPtr L)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = (AudioClip)luaObject;
		if (_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
		{
			LuaTypes luaTypes = default(LuaTypes);
			while (true)
			{
				int num = -141681288;
				while (true)
				{
					uint num2;
					switch ((num2 = (uint)(num ^ -1818820109)) % 7)
					{
					case 4u:
						break;
					case 2u:
						luaTypes = LuaDLL.lua_type(L, 1);
						num = (int)(num2 * 916396776) ^ -820228210;
						continue;
					case 0u:
						LuaDLL.luaL_error(L, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(3688549096u));
						num = -2008358562;
						continue;
					case 3u:
						num = ((int)num2 * -1952741660) ^ 0x68A8FC62;
						continue;
					case 1u:
					{
						int num3;
						int num4;
						if (luaTypes == LuaTypes.LUA_TTABLE)
						{
							num3 = -123136918;
							num4 = num3;
						}
						else
						{
							num3 = -1599981404;
							num4 = num3;
						}
						num = num3 ^ ((int)num2 * -733565292);
						continue;
					}
					case 6u:
						LuaDLL.luaL_error(L, global::_003CModule_003E._200B_202D_202D_202E_206D_202E_206C_200C_202B_200B_206E_202A_206C_206F_202B_206E_200E_206B_200E_206F_202E_202C_200B_200B_200C_206B_200C_200C_200C_202E_200C_200F_206F_202E_202D_206C_200D_200C_202E_206B_202E<string>(1101233122u));
						num = (int)((num2 * 311048480) ^ 0x3D6F9014);
						continue;
					default:
						goto end_IL_001b;
					}
					break;
				}
				continue;
				end_IL_001b:
				break;
			}
		}
		LuaScriptMgr.Push(L, (Enum)(object)_206B_200D_206B_206B_202C_200D_200E_206D_202D_206E_206A_202E_202B_200B_206E_202C_202A_200F_200B_206D_200D_202B_200C_206C_200B_202A_200C_206E_200F_206C_206B_206A_206B_206E_202B_202E_206F_206F_202D_202C_202E(val));
		return 1;
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int get_loadInBackground(IntPtr L)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Expected O, but got Unknown
		object luaObject = LuaScriptMgr.GetLuaObject(L, 1);
		AudioClip val = default(AudioClip);
		while (true)
		{
			int num = -301715484;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ -1372669596)) % 7)
				{
				case 4u:
					break;
				case 2u:
					LuaScriptMgr.Push(L, _200E_202A_202E_206E_202C_206B_202C_200C_202E_200F_206F_200D_202A_200C_206B_206A_206B_206C_200B_206A_206D_200C_206D_206E_202E_206F_200F_200F_202B_202A_206D_206E_202C_200F_206F_206D_206F_206D_200F_206D_202E(val));
					num = -291525532;
					continue;
				case 6u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._206E_202A_206F_206F_202C_206D_206F_206C_200F_206D_200D_200C_206A_206D_206C_206C_206F_202C_202C_200E_200C_206C_200D_206A_202E_202A_200C_202A_206B_200D_202E_200C_202E_200D_200B_200B_206E_200D_202C_206F_202E<string>(2550159944u));
					num = -474774788;
					continue;
				case 1u:
				{
					val = (AudioClip)luaObject;
					int num5;
					int num6;
					if (!_206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E((Object)(object)val, (Object)null))
					{
						num5 = -561968132;
						num6 = num5;
					}
					else
					{
						num5 = -50930094;
						num6 = num5;
					}
					num = num5 ^ ((int)num2 * -1725118310);
					continue;
				}
				case 3u:
				{
					LuaTypes luaTypes = LuaDLL.lua_type(L, 1);
					int num3;
					int num4;
					if (luaTypes != LuaTypes.LUA_TTABLE)
					{
						num3 = 1478807363;
						num4 = num3;
					}
					else
					{
						num3 = 1864297835;
						num4 = num3;
					}
					num = num3 ^ ((int)num2 * -953478232);
					continue;
				}
				case 0u:
					LuaDLL.luaL_error(L, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(4220676532u));
					num = (int)(num2 * 1641119647) ^ -1516082147;
					continue;
				default:
					return 1;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int LoadAudioData(IntPtr L)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		LuaScriptMgr.CheckArgsCount(L, 1);
		AudioClip val = (AudioClip)LuaScriptMgr.GetUnityObjectSelf(L, 1, global::_003CModule_003E._206D_206A_202B_200C_202A_200E_206D_202A_200B_206A_200F_200F_206C_206E_206A_200D_200E_202D_202C_202B_202B_206B_206A_202D_206D_200E_206F_206F_200C_206B_200F_202E_200E_200D_206E_202C_206C_206D_206C_206B_202E<string>(1278651591u));
		bool b = _200C_202D_202E_200B_206C_200C_200F_202B_206A_206C_206E_206B_200C_206C_202B_200F_206B_202B_200F_206C_206A_200E_200F_206C_200D_200F_206A_202A_200E_200C_200B_202C_200E_200F_200D_200F_206E_200E_200B_200D_202E(val);
		while (true)
		{
			int num = 515854828;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x469BFF4F)) % 3)
				{
				case 0u:
					break;
				case 2u:
					goto IL_0047;
				default:
					return 1;
				}
				break;
				IL_0047:
				LuaScriptMgr.Push(L, b);
				num = ((int)num2 * -684954187) ^ -2009521826;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int UnloadAudioData(IntPtr L)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		LuaScriptMgr.CheckArgsCount(L, 1);
		AudioClip val = (AudioClip)LuaScriptMgr.GetUnityObjectSelf(L, 1, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(1879990486u));
		bool b = default(bool);
		while (true)
		{
			int num = 1866220535;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x6BA6ECF)) % 3)
				{
				case 2u:
					break;
				case 1u:
					goto IL_0040;
				default:
					LuaScriptMgr.Push(L, b);
					return 1;
				}
				break;
				IL_0040:
				b = _206D_202B_200B_202C_200F_200D_206C_206B_206F_200B_206A_200D_202A_202B_202A_206D_200F_206E_202E_200F_200E_202D_206F_200F_200D_200E_200B_206A_202E_200B_206E_200F_206A_206C_200C_206A_206D_206B_200D_206E_202E(val);
				num = (int)(num2 * 1231532152) ^ -1223215891;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int GetData(IntPtr L)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		LuaScriptMgr.CheckArgsCount(L, 3);
		AudioClip val = (AudioClip)LuaScriptMgr.GetUnityObjectSelf(L, 1, global::_003CModule_003E._202E_200D_200D_200B_202E_206D_202C_200E_206B_200C_202C_206E_206A_200C_202C_202E_202C_200E_200E_206C_200D_200B_206B_200C_202E_202A_200B_206C_200F_206E_206E_202E_200F_206B_202C_206D_200F_202D_200E_202D_202E<string>(3330929139u));
		bool b = default(bool);
		float[] arrayNumber = default(float[]);
		while (true)
		{
			int num = 936378349;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x6F4CFEE9)) % 5)
				{
				case 3u:
					break;
				case 2u:
					LuaScriptMgr.Push(L, b);
					num = (int)(num2 * 1775092222) ^ -499111827;
					continue;
				case 0u:
				{
					int num3 = (int)LuaScriptMgr.GetNumber(L, 3);
					b = _200F_206F_202D_200E_200B_202D_200E_200F_206C_200C_202E_200E_200B_206D_200D_200E_202D_206A_200B_200D_200F_200D_200B_202C_200D_206C_200E_200E_206E_202A_200C_200C_206D_200E_202E_202A_200F_202E_200D_200E_202E(val, arrayNumber, num3);
					num = (int)(num2 * 490624307) ^ -69326426;
					continue;
				}
				case 4u:
					arrayNumber = LuaScriptMgr.GetArrayNumber<float>(L, 2);
					num = (int)((num2 * 87835947) ^ 0x7CFEC6FA);
					continue;
				default:
					return 1;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int SetData(IntPtr L)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		LuaScriptMgr.CheckArgsCount(L, 3);
		AudioClip val = (AudioClip)LuaScriptMgr.GetUnityObjectSelf(L, 1, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(1879990486u));
		float[] arrayNumber = default(float[]);
		int num3 = default(int);
		while (true)
		{
			int num = 962637060;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x4AB897DE)) % 3)
				{
				case 0u:
					break;
				case 1u:
					goto IL_0041;
				default:
				{
					bool b = _202B_202C_202D_202C_202E_200C_202D_206D_202A_202A_200E_202E_200E_206D_206D_206E_206F_202A_200C_202D_200E_200C_200D_200D_200D_202A_206C_200F_206F_206A_200B_202B_202E_206D_202E_206B_202D_202B_202A_200F_202E(val, arrayNumber, num3);
					LuaScriptMgr.Push(L, b);
					return 1;
				}
				}
				break;
				IL_0041:
				arrayNumber = LuaScriptMgr.GetArrayNumber<float>(L, 2);
				num3 = (int)LuaScriptMgr.GetNumber(L, 3);
				num = (int)((num2 * 571125396) ^ 0x209BFA72);
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int Create(IntPtr L)
	{
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Expected O, but got Unknown
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Expected O, but got Unknown
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Expected O, but got Unknown
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Expected O, but got Unknown
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Expected O, but got Unknown
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Expected O, but got Unknown
		_206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E obj = new _206B_206E_200D_202D_200D_206D_200E_206A_200D_206E_202B_200D_202A_200F_200B_206A_206B_206C_202A_202B_200C_200D_202E_200E_200E_206C_200C_200C_200F_202E_200F_202C_206B_206B_206D_206E_202A_206D_202E_206A_202E();
		string luaString3 = default(string);
		int num17 = default(int);
		int num11 = default(int);
		PCMSetPositionCallback val3 = default(PCMSetPositionCallback);
		_202D_202E_200D_206D_202A_206F_206E_202B_202C_202A_200D_202A_202B_202E_202B_206A_200F_206F_206C_202E_200E_202D_202C_200F_206C_206E_202E_202A_202E_206D_206D_200E_200D_200C_200E_206D_202A_200B_206C_202E obj3 = default(_202D_202E_200D_206D_202A_206F_206E_202B_202C_202A_200D_202A_202B_202E_202B_206A_200F_206F_206C_202E_200E_202D_202C_200F_206C_206E_202E_202A_202E_206D_206D_200E_200D_200C_200E_206D_202A_200B_206C_202E);
		int num13 = default(int);
		bool boolean3 = default(bool);
		AudioClip obj6 = default(AudioClip);
		string luaString2 = default(string);
		int num10 = default(int);
		int num19 = default(int);
		int num9 = default(int);
		bool boolean2 = default(bool);
		LuaTypes luaTypes2 = default(LuaTypes);
		int num20 = default(int);
		int num3 = default(int);
		bool boolean = default(bool);
		PCMReaderCallback val = default(PCMReaderCallback);
		int num12 = default(int);
		PCMReaderCallback val2 = default(PCMReaderCallback);
		string luaString = default(string);
		int num8 = default(int);
		_200B_200F_202B_206D_202D_206C_202D_202B_206E_200B_202C_200B_206D_202E_206D_202A_206D_200E_206A_206D_206A_206B_206F_206A_200E_202B_202E_202B_202E_206A_202E_200E_206E_202B_202D_202E_202A_200B_200D_202A_202E obj2 = default(_200B_200F_202B_206D_202D_206C_202D_202B_206E_200B_202C_200B_206D_202E_206D_202A_206D_200E_206A_206D_206A_206B_206F_206A_200E_202B_202E_202B_202E_206A_202E_200E_206E_202B_202D_202E_202A_200B_200D_202A_202E);
		_200B_200E_200C_202A_206E_202D_206C_200B_206F_200B_200D_200E_202D_202A_202E_202A_202C_202C_200C_206C_206D_200E_202B_206B_206F_206A_202C_200E_202C_206D_202E_206D_206E_200F_206D_202D_200B_206F_202E_206F_202E obj4 = default(_200B_200E_200C_202A_206E_202D_206C_200B_206F_200B_200D_200E_202D_202A_202E_202A_202C_202C_200C_206C_206D_200E_202B_206B_206F_206A_202C_200E_202C_206D_202E_206D_206E_200F_206D_202D_200B_206F_202E_206F_202E);
		LuaTypes luaTypes = default(LuaTypes);
		while (true)
		{
			int num = 926925741;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x1C021442)) % 43)
				{
				case 20u:
					break;
				case 7u:
					luaString3 = LuaScriptMgr.GetLuaString(obj.L, 1);
					num17 = (int)LuaScriptMgr.GetNumber(obj.L, 2);
					num = (int)((num2 * 1769548607) ^ 0x7A8019B0);
					continue;
				case 0u:
				{
					int num15;
					int num16;
					if (num11 != 5)
					{
						num15 = -2143346674;
						num16 = num15;
					}
					else
					{
						num15 = -218831052;
						num16 = num15;
					}
					num = num15 ^ ((int)num2 * -1373389988);
					continue;
				}
				case 1u:
					num = (int)(num2 * 858947732) ^ -1892539939;
					continue;
				case 22u:
					val3 = new PCMSetPositionCallback(obj3._200B_200E_206A_200F_202C_200E_200D_206E_206D_206B_206D_202D_200F_206D_206C_200F_200F_200F_202D_202D_202E_200F_202C_206B_206A_200F_206C_200F_206E_200E_206E_200C_200C_206E_200B_202B_200C_206D_206B_202B_202E);
					num = ((int)num2 * -431512537) ^ 0x32A86FC1;
					continue;
				case 26u:
					num13 = (int)LuaScriptMgr.GetNumber(obj.L, 4);
					boolean3 = LuaScriptMgr.GetBoolean(obj.L, 5);
					num = ((int)num2 * -679399499) ^ -1894611582;
					continue;
				case 13u:
					obj6 = _200B_200C_206E_200F_206C_202E_200B_202A_206B_202D_206D_206F_202C_202A_200F_206D_206E_202D_202B_200F_202E_206D_206B_206D_200F_202D_202C_200F_206B_202E_200B_202B_206F_202A_200B_200F_206C_206F_206F_206B_202E(luaString2, num10, num19, num9, boolean2);
					num = ((int)num2 * -697267544) ^ -1063239799;
					continue;
				case 12u:
				{
					int num6;
					int num7;
					if (luaTypes2 != LuaTypes.LUA_TFUNCTION)
					{
						num6 = 1447566872;
						num7 = num6;
					}
					else
					{
						num6 = 363516318;
						num7 = num6;
					}
					num = num6 ^ ((int)num2 * -326183320);
					continue;
				}
				case 3u:
					luaTypes2 = LuaDLL.lua_type(obj.L, 6);
					num = ((int)num2 * -1740416717) ^ -237432303;
					continue;
				case 4u:
				{
					int num21;
					if (num11 == 7)
					{
						num = 1371047219;
						num21 = num;
					}
					else
					{
						num = 527307624;
						num21 = num;
					}
					continue;
				}
				case 34u:
					num19 = (int)LuaScriptMgr.GetNumber(obj.L, 3);
					num = (int)((num2 * 1112543238) ^ 0x3BD3F4C9);
					continue;
				case 41u:
					LuaScriptMgr.Push(obj.L, (Object)(object)obj6);
					return 1;
				case 5u:
				{
					AudioClip obj7 = _202C_200B_202B_206D_200F_202E_206D_206B_200B_200C_202C_206C_200D_206C_202A_206A_206F_200E_206B_202A_206F_206F_202A_202C_202E_200E_206E_206A_206D_200B_200C_202D_200C_206E_200D_202D_202E_206E_200B_206D_202E(luaString3, num17, num20, num3, boolean, val);
					LuaScriptMgr.Push(obj.L, (Object)(object)obj7);
					num = 1120277224;
					continue;
				}
				case 27u:
					obj3._202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E = obj;
					num = (int)((num2 * 35352890) ^ 0x4A8447D1);
					continue;
				case 38u:
					num20 = (int)LuaScriptMgr.GetNumber(obj.L, 3);
					num = (int)((num2 * 1640013842) ^ 0x22D52D77);
					continue;
				case 32u:
					num12 = (int)LuaScriptMgr.GetNumber(obj.L, 2);
					num = (int)(num2 * 1019064481) ^ -914210101;
					continue;
				case 23u:
					val3 = (PCMSetPositionCallback)LuaScriptMgr.GetNetObject(obj.L, 7, _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(PCMSetPositionCallback).TypeHandle));
					num = ((int)num2 * -933955178) ^ 0x39A7F695;
					continue;
				case 28u:
					val2 = (PCMReaderCallback)LuaScriptMgr.GetNetObject(obj.L, 6, _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(PCMReaderCallback).TypeHandle));
					num = ((int)num2 * -1705845638) ^ 0x328BF64E;
					continue;
				case 24u:
				{
					int num18;
					if (num11 == 6)
					{
						num = 1724127853;
						num18 = num;
					}
					else
					{
						num = 1353286939;
						num18 = num;
					}
					continue;
				}
				case 40u:
				{
					val3 = null;
					LuaTypes luaTypes3 = LuaDLL.lua_type(obj.L, 7);
					int num14;
					if (luaTypes3 != LuaTypes.LUA_TFUNCTION)
					{
						num = 2092911394;
						num14 = num;
					}
					else
					{
						num = 1735906980;
						num14 = num;
					}
					continue;
				}
				case 19u:
					val = (PCMReaderCallback)LuaScriptMgr.GetNetObject(obj.L, 6, _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(typeof(PCMReaderCallback).TypeHandle));
					num = ((int)num2 * -326605173) ^ 0x4B0F75E5;
					continue;
				case 8u:
				{
					AudioClip obj5 = _206C_202E_200C_200E_202D_202A_202B_200B_202B_202E_202B_200B_202C_200B_200B_202C_202D_200F_206E_200F_206E_202D_202A_202B_206D_206D_202D_202C_206B_206A_200F_206E_200C_202C_206A_206F_202A_206E_206E_200D_202E(luaString, num12, num8, num13, boolean3, val2, val3);
					LuaScriptMgr.Push(obj.L, (Object)(object)obj5);
					num = 44447001;
					continue;
				}
				case 2u:
					obj2._202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E = obj;
					obj2.func = LuaScriptMgr.GetLuaFunction(obj.L, 6);
					val = new PCMReaderCallback(obj2._206B_206A_202A_206D_200D_206D_206C_200E_200E_200C_206E_200D_202B_200F_202B_206E_206B_200B_206C_206D_200C_206E_200E_202D_200D_202A_206F_206F_206C_202A_202A_202B_202B_206D_200F_200F_202A_200F_200D_200F_202E);
					num = (int)(num2 * 93724857) ^ -1312123309;
					continue;
				case 10u:
					obj.L = L;
					num11 = LuaDLL.lua_gettop(obj.L);
					num = ((int)num2 * -283999723) ^ 0x2DF4C119;
					continue;
				case 25u:
					num10 = (int)LuaScriptMgr.GetNumber(obj.L, 2);
					num = ((int)num2 * -141443778) ^ -608043868;
					continue;
				case 33u:
					val2 = new PCMReaderCallback(obj4._206E_206A_202E_206D_206E_202C_200C_202A_200F_200B_206A_200F_202E_202E_206C_206F_202D_202A_200D_200F_206F_200B_202E_206B_200B_200C_206B_202B_200E_200E_202A_202E_206D_206B_202B_200E_206D_206A_200B_200E_202E);
					num = (int)((num2 * 862610629) ^ 0x42F18CC);
					continue;
				case 14u:
					obj3 = new _202D_202E_200D_206D_202A_206F_206E_202B_202C_202A_200D_202A_202B_202E_202B_206A_200F_206F_206C_202E_200E_202D_202C_200F_206C_206E_202E_202A_202E_206D_206D_200E_200D_200C_200E_206D_202A_200B_206C_202E();
					num = 510216702;
					continue;
				case 15u:
					luaString2 = LuaScriptMgr.GetLuaString(obj.L, 1);
					num = ((int)num2 * -1296898150) ^ 0x2EA1C897;
					continue;
				case 9u:
					num9 = (int)LuaScriptMgr.GetNumber(obj.L, 4);
					boolean2 = LuaScriptMgr.GetBoolean(obj.L, 5);
					num = ((int)num2 * -206618147) ^ -664331556;
					continue;
				case 18u:
					return 1;
				case 21u:
					num8 = (int)LuaScriptMgr.GetNumber(obj.L, 3);
					num = (int)(num2 * 744814422) ^ -21726159;
					continue;
				case 31u:
					num = ((int)num2 * -530489157) ^ 0x4B084673;
					continue;
				case 39u:
				{
					int num4;
					int num5;
					if (luaTypes == LuaTypes.LUA_TFUNCTION)
					{
						num4 = -576318319;
						num5 = num4;
					}
					else
					{
						num4 = -735630184;
						num5 = num4;
					}
					num = num4 ^ ((int)num2 * -1418474633);
					continue;
				}
				case 35u:
					obj4._202B_206A_206F_206A_206E_200F_202D_200E_202E_206D_202D_202C_206C_200D_202E_206A_206B_200B_206E_202C_202D_200D_202D_206E_206B_206A_202A_200C_200E_202A_202D_202D_200D_200B_200B_206A_206E_206A_200E_200E_202E = obj;
					obj4.func = LuaScriptMgr.GetLuaFunction(obj.L, 6);
					num = (int)(num2 * 1952731629) ^ -509516873;
					continue;
				case 30u:
					val2 = null;
					num = ((int)num2 * -1510335719) ^ -1304013030;
					continue;
				case 16u:
					luaTypes = LuaDLL.lua_type(obj.L, 6);
					num = ((int)num2 * -372193691) ^ -310838655;
					continue;
				case 11u:
					return 1;
				case 37u:
					luaString = LuaScriptMgr.GetLuaString(obj.L, 1);
					num = (int)(num2 * 829746532) ^ -1473493516;
					continue;
				case 29u:
					num3 = (int)LuaScriptMgr.GetNumber(obj.L, 4);
					boolean = LuaScriptMgr.GetBoolean(obj.L, 5);
					val = null;
					num = ((int)num2 * -179277376) ^ -1769179229;
					continue;
				case 36u:
					obj4 = new _200B_200E_200C_202A_206E_202D_206C_200B_206F_200B_200D_200E_202D_202A_202E_202A_202C_202C_200C_206C_206D_200E_202B_206B_206F_206A_202C_200E_202C_206D_202E_206D_206E_200F_206D_202D_200B_206F_202E_206F_202E();
					num = 1526055908;
					continue;
				case 42u:
					obj3.func = LuaScriptMgr.GetLuaFunction(obj.L, 7);
					num = ((int)num2 * -1395749735) ^ -1528103651;
					continue;
				case 17u:
					obj2 = new _200B_200F_202B_206D_202D_206C_202D_202B_206E_200B_202C_200B_206D_202E_206D_202A_206D_200E_206A_206D_206A_206B_206F_206A_200E_202B_202E_202B_202E_206A_202E_200E_206E_202B_202D_202E_202A_200B_200D_202A_202E();
					num = 1925590160;
					continue;
				default:
					LuaDLL.luaL_error(obj.L, global::_003CModule_003E._206E_202E_200E_202B_202E_206D_200E_206E_206C_206D_206D_206A_200C_202D_202D_202D_206C_202D_200D_206F_206F_206B_202C_206D_202C_206D_200F_206F_206A_200C_202A_202B_200D_202A_202D_206B_200F_206F_200C_206D_202E<string>(2074683682u));
					return 0;
				}
				break;
			}
		}
	}

	[MonoPInvokeCallback(typeof(LuaCSFunction))]
	private static int Lua_Eq(IntPtr L)
	{
		LuaScriptMgr.CheckArgsCount(L, 2);
		Object val = default(Object);
		Object val2 = default(Object);
		while (true)
		{
			int num = 1048752673;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num ^ 0x24A2BCDF)) % 4)
				{
				case 3u:
					break;
				case 2u:
				{
					object luaObject2 = LuaScriptMgr.GetLuaObject(L, 1);
					val = (Object)((luaObject2 is Object) ? luaObject2 : null);
					num = (int)((num2 * 268905191) ^ 0xE17D9E8);
					continue;
				}
				case 1u:
				{
					object luaObject = LuaScriptMgr.GetLuaObject(L, 2);
					val2 = (Object)((luaObject is Object) ? luaObject : null);
					num = ((int)num2 * -1963818014) ^ 0x5DC02001;
					continue;
				}
				default:
				{
					bool b = _206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E(val, val2);
					LuaScriptMgr.Push(L, b);
					return 1;
				}
				}
				break;
			}
		}
	}

	static Type _202C_202A_200C_200B_200C_206D_200C_206A_202A_206D_206F_200F_200F_202B_202B_202A_206B_202D_206E_202B_206A_206C_206A_206D_200D_206B_202D_206E_206E_200B_200B_206F_202E_206E_202C_206F_200F_206C_202C_202C_202E(RuntimeTypeHandle P_0)
	{
		return Type.GetTypeFromHandle(P_0);
	}

	static AudioClip _206B_206D_206C_202C_206F_202B_206D_206E_202C_206E_206F_202E_202D_200E_200C_202C_202B_200B_200F_202A_200E_200D_200B_206A_206F_202E_200F_206C_202A_206B_202D_206A_202C_206A_206D_200B_202E_206D_202C_202B_202E()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected O, but got Unknown
		return new AudioClip();
	}

	static bool _206F_202A_200F_200F_202B_200C_202C_200C_200F_206C_200C_202C_206F_202E_200D_206C_206C_200C_206B_202C_206D_200C_200D_202A_200E_206D_202C_206F_206A_200D_206F_202D_200F_206B_202E_206B_206A_202D_206E_206D_202E(Object P_0, Object P_1)
	{
		return P_0 == P_1;
	}

	static float _202B_202D_202C_202D_200E_200E_202C_206F_200C_206C_206F_206A_202A_206F_200C_206B_202C_206E_206E_206C_206C_202A_200B_200C_206C_206D_202A_202E_200B_206B_202D_206F_206C_206A_200B_202A_206B_202C_200D_206A_202E(AudioClip P_0)
	{
		return P_0.length;
	}

	static int _206D_202E_200E_206D_200B_206F_206F_206E_206D_206E_206A_202B_206A_206A_206D_202E_206C_202D_200C_200D_202C_202C_206D_200C_206B_206B_206F_200D_206A_202C_206E_200E_202B_202D_200F_206E_202B_200C_206C_200F_202E(AudioClip P_0)
	{
		return P_0.samples;
	}

	static int _202D_206E_202B_206E_206D_206A_200D_206A_200E_200C_200C_206E_206A_202C_200D_202E_206B_206D_202A_202A_202A_206B_202B_200B_200E_202E_200C_202A_200B_202B_206B_200E_206B_206A_200F_200F_200E_202C_206E_202E(AudioClip P_0)
	{
		return P_0.channels;
	}

	static int _200F_200C_202A_206A_202C_202D_202A_200F_206C_202C_206E_200E_206F_206E_200D_200D_200E_206D_200E_206B_202C_202A_206F_200E_206E_200D_206C_200C_206F_206E_202D_206A_206C_206C_200E_202D_200C_206C_206D_202A_202E(AudioClip P_0)
	{
		return P_0.frequency;
	}

	static AudioClipLoadType _206A_206B_200E_206F_200B_200E_200D_202D_206B_200C_200E_200E_200E_202E_202E_206D_200E_206A_206A_206D_206E_206A_206F_206F_200F_206F_200D_202B_206F_200F_206A_206A_206B_202E_202B_206D_202B_200C_202C_202B_202E(AudioClip P_0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return P_0.loadType;
	}

	static bool _200B_202A_206A_202C_202C_202C_206A_202A_200E_202E_200B_202E_202B_200D_206B_202C_200B_200C_202B_202C_200B_202C_200E_200C_200F_200D_206E_202B_200C_202C_200C_206E_206F_202B_202D_200F_202B_202D_202D_202E(AudioClip P_0)
	{
		return P_0.preloadAudioData;
	}

	static AudioDataLoadState _206B_200D_206B_206B_202C_200D_200E_206D_202D_206E_206A_202E_202B_200B_206E_202C_202A_200F_200B_206D_200D_202B_200C_206C_200B_202A_200C_206E_200F_206C_206B_206A_206B_206E_202B_202E_206F_206F_202D_202C_202E(AudioClip P_0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return P_0.loadState;
	}

	static bool _200E_202A_202E_206E_202C_206B_202C_200C_202E_200F_206F_200D_202A_200C_206B_206A_206B_206C_200B_206A_206D_200C_206D_206E_202E_206F_200F_200F_202B_202A_206D_206E_202C_200F_206F_206D_206F_206D_200F_206D_202E(AudioClip P_0)
	{
		return P_0.loadInBackground;
	}

	static bool _200C_202D_202E_200B_206C_200C_200F_202B_206A_206C_206E_206B_200C_206C_202B_200F_206B_202B_200F_206C_206A_200E_200F_206C_200D_200F_206A_202A_200E_200C_200B_202C_200E_200F_200D_200F_206E_200E_200B_200D_202E(AudioClip P_0)
	{
		return P_0.LoadAudioData();
	}

	static bool _206D_202B_200B_202C_200F_200D_206C_206B_206F_200B_206A_200D_202A_202B_202A_206D_200F_206E_202E_200F_200E_202D_206F_200F_200D_200E_200B_206A_202E_200B_206E_200F_206A_206C_200C_206A_206D_206B_200D_206E_202E(AudioClip P_0)
	{
		return P_0.UnloadAudioData();
	}

	static bool _200F_206F_202D_200E_200B_202D_200E_200F_206C_200C_202E_200E_200B_206D_200D_200E_202D_206A_200B_200D_200F_200D_200B_202C_200D_206C_200E_200E_206E_202A_200C_200C_206D_200E_202E_202A_200F_202E_200D_200E_202E(AudioClip P_0, float[] P_1, int P_2)
	{
		return P_0.GetData(P_1, P_2);
	}

	static bool _202B_202C_202D_202C_202E_200C_202D_206D_202A_202A_200E_202E_200E_206D_206D_206E_206F_202A_200C_202D_200E_200C_200D_200D_200D_202A_206C_200F_206F_206A_200B_202B_202E_206D_202E_206B_202D_202B_202A_200F_202E(AudioClip P_0, float[] P_1, int P_2)
	{
		return P_0.SetData(P_1, P_2);
	}

	static AudioClip _200B_200C_206E_200F_206C_202E_200B_202A_206B_202D_206D_206F_202C_202A_200F_206D_206E_202D_202B_200F_202E_206D_206B_206D_200F_202D_202C_200F_206B_202E_200B_202B_206F_202A_200B_200F_206C_206F_206F_206B_202E(string P_0, int P_1, int P_2, int P_3, bool P_4)
	{
		return AudioClip.Create(P_0, P_1, P_2, P_3, P_4);
	}

	static AudioClip _202C_200B_202B_206D_200F_202E_206D_206B_200B_200C_202C_206C_200D_206C_202A_206A_206F_200E_206B_202A_206F_206F_202A_202C_202E_200E_206E_206A_206D_200B_200C_202D_200C_206E_200D_202D_202E_206E_200B_206D_202E(string P_0, int P_1, int P_2, int P_3, bool P_4, PCMReaderCallback P_5)
	{
		return AudioClip.Create(P_0, P_1, P_2, P_3, P_4, P_5);
	}

	static AudioClip _206C_202E_200C_200E_202D_202A_202B_200B_202B_202E_202B_200B_202C_200B_200B_202C_202D_200F_206E_200F_206E_202D_202A_202B_206D_206D_202D_202C_206B_206A_200F_206E_200C_202C_206A_206F_202A_206E_206E_200D_202E(string P_0, int P_1, int P_2, int P_3, bool P_4, PCMReaderCallback P_5, PCMSetPositionCallback P_6)
	{
		return AudioClip.Create(P_0, P_1, P_2, P_3, P_4, P_5, P_6);
	}
}
