﻿using System;

namespace Mono.Remoting.Channels.Unix
{
	// Token: 0x02000082 RID: 130
	internal enum MessageStatus
	{
		// Token: 0x04000438 RID: 1080
		MethodMessage,
		// Token: 0x04000439 RID: 1081
		CancelSignal,
		// Token: 0x0400043A RID: 1082
		Unknown = 10
	}
}
