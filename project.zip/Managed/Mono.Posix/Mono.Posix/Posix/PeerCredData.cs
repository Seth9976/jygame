﻿using System;

namespace Mono.Posix
{
	// Token: 0x0200006B RID: 107
	internal struct PeerCredData
	{
		// Token: 0x040003B0 RID: 944
		public int pid;

		// Token: 0x040003B1 RID: 945
		public int uid;

		// Token: 0x040003B2 RID: 946
		public int gid;
	}
}
