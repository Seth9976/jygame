﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyProduct("Debuger")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTitle("Debuger")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("358d2fb2-5510-4b32-ae8a-e213cc59f068")]
[assembly: AssemblyFileVersion("1.0.0.0")]
