﻿using System;

namespace DG.Tweening.Core
{
	// Token: 0x0200002E RID: 46
	// (Invoke) Token: 0x06000168 RID: 360
	public delegate float EaseFunction(float time, float startValue, float changeValue, float duration, float overshootOrAmplitude, float period);
}
