﻿using System;

namespace DG.Tweening.Core
{
	// Token: 0x0200002C RID: 44
	// (Invoke) Token: 0x06000160 RID: 352
	public delegate void DOSetter<in T>(T pNewValue);
}
