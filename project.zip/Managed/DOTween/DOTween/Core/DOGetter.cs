﻿using System;

namespace DG.Tweening.Core
{
	// Token: 0x0200002B RID: 43
	// (Invoke) Token: 0x0600015C RID: 348
	public delegate T DOGetter<out T>();
}
