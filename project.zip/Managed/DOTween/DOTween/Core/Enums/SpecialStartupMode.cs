﻿using System;

namespace DG.Tweening.Core.Enums
{
	// Token: 0x02000016 RID: 22
	internal enum SpecialStartupMode
	{
		// Token: 0x04000069 RID: 105
		None,
		// Token: 0x0400006A RID: 106
		SetLookAt,
		// Token: 0x0400006B RID: 107
		SetShake,
		// Token: 0x0400006C RID: 108
		SetPunch,
		// Token: 0x0400006D RID: 109
		SetCameraShakePosition
	}
}
