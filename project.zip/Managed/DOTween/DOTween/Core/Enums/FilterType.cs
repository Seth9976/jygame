﻿using System;

namespace DG.Tweening.Core.Enums
{
	// Token: 0x02000041 RID: 65
	internal enum FilterType
	{
		// Token: 0x04000121 RID: 289
		All,
		// Token: 0x04000122 RID: 290
		TargetOrId,
		// Token: 0x04000123 RID: 291
		DOGetter
	}
}
