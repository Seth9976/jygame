﻿using System;

namespace DG.Tweening.Core.Enums
{
	// Token: 0x0200003B RID: 59
	internal enum UpdateMode
	{
		// Token: 0x0400010A RID: 266
		Update,
		// Token: 0x0400010B RID: 267
		Goto
	}
}
