﻿using System;

namespace DG.Tweening.Core
{
	// Token: 0x0200002D RID: 45
	// (Invoke) Token: 0x06000164 RID: 356
	public delegate void TweenCallback();
}
