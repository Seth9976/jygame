﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000014 RID: 20
	public enum LoopType
	{
		// Token: 0x04000065 RID: 101
		Restart,
		// Token: 0x04000066 RID: 102
		Yoyo,
		// Token: 0x04000067 RID: 103
		Incremental
	}
}
