﻿using System;

namespace DG.Tweening.Plugins.Core
{
	// Token: 0x02000002 RID: 2
	public interface ITweenPlugin
	{
	}
}
