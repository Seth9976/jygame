﻿using System;

namespace DG.Tweening.Plugins.Core
{
	// Token: 0x02000045 RID: 69
	public interface ITPlugin<T1, out T2, out TPlugOptions, TPlugin>
	{
	}
}
