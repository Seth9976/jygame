﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x0200001A RID: 26
	public struct NoOptions
	{
	}
}
