﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x0200003F RID: 63
	public struct VectorOptions
	{
		// Token: 0x0400011E RID: 286
		public AxisConstraint axisConstraint;

		// Token: 0x0400011F RID: 287
		public bool snapping;
	}
}
