﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x02000025 RID: 37
	public struct Vector3ArrayOptions
	{
		// Token: 0x040000BC RID: 188
		public AxisConstraint axisConstraint;

		// Token: 0x040000BD RID: 189
		public bool snapping;

		// Token: 0x040000BE RID: 190
		internal float[] durations;
	}
}
