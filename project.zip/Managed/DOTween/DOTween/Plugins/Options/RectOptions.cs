﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x02000012 RID: 18
	public struct RectOptions
	{
		// Token: 0x04000062 RID: 98
		public bool snapping;
	}
}
