﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x02000013 RID: 19
	public struct ColorOptions
	{
		// Token: 0x04000063 RID: 99
		public bool alphaOnly;
	}
}
