﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x02000030 RID: 48
	public enum OrientType
	{
		// Token: 0x040000CC RID: 204
		None,
		// Token: 0x040000CD RID: 205
		ToPath,
		// Token: 0x040000CE RID: 206
		LookAtTransform,
		// Token: 0x040000CF RID: 207
		LookAtPosition
	}
}
