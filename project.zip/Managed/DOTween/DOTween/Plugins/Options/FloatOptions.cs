﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x0200004A RID: 74
	public struct FloatOptions
	{
		// Token: 0x04000132 RID: 306
		public bool snapping;
	}
}
