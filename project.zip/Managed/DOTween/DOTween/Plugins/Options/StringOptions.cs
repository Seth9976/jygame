﻿using System;

namespace DG.Tweening.Plugins.Options
{
	// Token: 0x02000039 RID: 57
	public struct StringOptions
	{
		// Token: 0x04000107 RID: 263
		public bool scramble;

		// Token: 0x04000108 RID: 264
		public char[] scrambledChars;
	}
}
