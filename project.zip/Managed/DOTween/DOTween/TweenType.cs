﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000020 RID: 32
	public enum TweenType
	{
		// Token: 0x0400009D RID: 157
		Tweener,
		// Token: 0x0400009E RID: 158
		Sequence,
		// Token: 0x0400009F RID: 159
		Callback
	}
}
