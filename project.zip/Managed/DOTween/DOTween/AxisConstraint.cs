﻿using System;

namespace DG.Tweening
{
	// Token: 0x0200004D RID: 77
	[Flags]
	public enum AxisConstraint
	{
		// Token: 0x04000138 RID: 312
		None = 0,
		// Token: 0x04000139 RID: 313
		X = 2,
		// Token: 0x0400013A RID: 314
		Y = 4,
		// Token: 0x0400013B RID: 315
		Z = 8,
		// Token: 0x0400013C RID: 316
		W = 16
	}
}
