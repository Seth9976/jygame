﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000005 RID: 5
	public enum RotateMode
	{
		// Token: 0x04000002 RID: 2
		Fast,
		// Token: 0x04000003 RID: 3
		FastBeyond360,
		// Token: 0x04000004 RID: 4
		WorldAxisAdd,
		// Token: 0x04000005 RID: 5
		LocalAxisAdd
	}
}
