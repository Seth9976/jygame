﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000046 RID: 70
	public enum AutoPlay
	{
		// Token: 0x0400012B RID: 299
		None,
		// Token: 0x0400012C RID: 300
		AutoPlaySequences,
		// Token: 0x0400012D RID: 301
		AutoPlayTweeners,
		// Token: 0x0400012E RID: 302
		All
	}
}
