﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000038 RID: 56
	public enum PathMode
	{
		// Token: 0x04000104 RID: 260
		Full3D,
		// Token: 0x04000105 RID: 261
		TopDown2D,
		// Token: 0x04000106 RID: 262
		Sidescroller2D
	}
}
