﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000007 RID: 7
	public interface IDOTweenInit
	{
		// Token: 0x06000012 RID: 18
		IDOTweenInit SetCapacity(int tweenersCapacity, int sequencesCapacity);
	}
}
