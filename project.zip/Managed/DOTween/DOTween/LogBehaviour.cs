﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000021 RID: 33
	public enum LogBehaviour
	{
		// Token: 0x040000A1 RID: 161
		Default,
		// Token: 0x040000A2 RID: 162
		Verbose,
		// Token: 0x040000A3 RID: 163
		ErrorsOnly
	}
}
