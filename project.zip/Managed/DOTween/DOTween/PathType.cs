﻿using System;

namespace DG.Tweening
{
	// Token: 0x0200004B RID: 75
	public enum PathType
	{
		// Token: 0x04000134 RID: 308
		Linear,
		// Token: 0x04000135 RID: 309
		CatmullRom
	}
}
