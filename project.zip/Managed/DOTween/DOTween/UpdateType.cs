﻿using System;

namespace DG.Tweening
{
	// Token: 0x02000048 RID: 72
	public enum UpdateType
	{
		// Token: 0x04000130 RID: 304
		Default,
		// Token: 0x04000131 RID: 305
		Late
	}
}
