﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: Guid("807e068c-2a0e-4c81-a303-4b4fd3924511")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: InternalsVisibleTo("DOTweenEditor")]
[assembly: AssemblyCopyright("Copyright © Daniele Giardini, 2014")]
[assembly: InternalsVisibleTo("DOTweenPro")]
[assembly: AssemblyProduct("DOTween")]
[assembly: ComVisible(false)]
[assembly: InternalsVisibleTo("DOTween43")]
[assembly: InternalsVisibleTo("DOTweenProEditor")]
[assembly: AssemblyTitle("DOTween")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Demigiant")]
